-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2017 at 12:01 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exchanger`
--

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `pertanyaan` text NOT NULL,
  `jawaban` text NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `pesan` text NOT NULL,
  `status` int(2) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pencairan`
--

CREATE TABLE `pencairan` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `btc` decimal(10,8) NOT NULL,
  `rate` int(11) NOT NULL,
  `nominalnet` int(11) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `norek` varchar(255) NOT NULL,
  `atasnama` varchar(255) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `riwayattx`
--

CREATE TABLE `riwayattx` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `matauang` varchar(50) NOT NULL,
  `nominal` varchar(100) NOT NULL,
  `status` decimal(10,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `telegram`
--

CREATE TABLE `telegram` (
  `no` int(25) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statusblokir` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_doge_bitcoin`
--

CREATE TABLE `transaksi_doge_bitcoin` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_doge_bitcoin_done`
--

CREATE TABLE `transaksi_doge_bitcoin_done` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `iduserasal` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_litecoin_bitcoin`
--

CREATE TABLE `transaksi_litecoin_bitcoin` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_litecoin_bitcoin_done`
--

CREATE TABLE `transaksi_litecoin_bitcoin_done` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `iduserasal` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_litkoin_bitcoin`
--

CREATE TABLE `transaksi_litkoin_bitcoin` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_litkoin_bitcoin_done`
--

CREATE TABLE `transaksi_litkoin_bitcoin_done` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `iduserasal` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_tele_bitcoin`
--

CREATE TABLE `transaksi_tele_bitcoin` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_tele_bitcoin_done`
--

CREATE TABLE `transaksi_tele_bitcoin_done` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `iduserasal` varchar(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `rate` double(100,8) NOT NULL,
  `jumlah` double(100,8) NOT NULL,
  `total` double(100,8) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `iduser` varchar(11) NOT NULL,
  `leader` varchar(50) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `tanggaljam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `alamatbitcoin` varchar(225) NOT NULL,
  `alamatdogecoin` varchar(225) NOT NULL,
  `alamatlitecoin` varchar(225) NOT NULL,
  `alamattellecoin` varchar(225) NOT NULL,
  `alamatlitkoin` varchar(225) NOT NULL,
  `saldobitcoin` double(100,8) NOT NULL,
  `saldodogecoin` double(100,8) NOT NULL,
  `saldolitecoin` double(100,8) NOT NULL,
  `saldotellecoin` double(100,8) NOT NULL,
  `saldolitkoin` double(100,8) NOT NULL,
  `blokir` int(11) NOT NULL DEFAULT '1',
  `status` varchar(25) NOT NULL,
  `tanda` int(11) NOT NULL,
  `tanda2` int(11) NOT NULL,
  `tanda3` int(11) NOT NULL,
  `level` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pencairan`
--
ALTER TABLE `pencairan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `riwayattx`
--
ALTER TABLE `riwayattx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `telegram`
--
ALTER TABLE `telegram`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `transaksi_doge_bitcoin`
--
ALTER TABLE `transaksi_doge_bitcoin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `transaksi_doge_bitcoin_done`
--
ALTER TABLE `transaksi_doge_bitcoin_done`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `transaksi_litecoin_bitcoin`
--
ALTER TABLE `transaksi_litecoin_bitcoin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `transaksi_litecoin_bitcoin_done`
--
ALTER TABLE `transaksi_litecoin_bitcoin_done`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `transaksi_litkoin_bitcoin`
--
ALTER TABLE `transaksi_litkoin_bitcoin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `transaksi_litkoin_bitcoin_done`
--
ALTER TABLE `transaksi_litkoin_bitcoin_done`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `transaksi_tele_bitcoin`
--
ALTER TABLE `transaksi_tele_bitcoin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `transaksi_tele_bitcoin_done`
--
ALTER TABLE `transaksi_tele_bitcoin_done`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alamatbitcoin` (`alamatbitcoin`),
  ADD UNIQUE KEY `alamatdogecoin` (`alamatdogecoin`),
  ADD UNIQUE KEY `alamatlitecoin` (`alamatlitecoin`),
  ADD UNIQUE KEY `alamattellecoin` (`alamattellecoin`),
  ADD UNIQUE KEY `alamatlitkoin` (`alamatlitkoin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pencairan`
--
ALTER TABLE `pencairan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riwayattx`
--
ALTER TABLE `riwayattx`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `telegram`
--
ALTER TABLE `telegram`
  MODIFY `no` int(25) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_doge_bitcoin`
--
ALTER TABLE `transaksi_doge_bitcoin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_doge_bitcoin_done`
--
ALTER TABLE `transaksi_doge_bitcoin_done`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_litecoin_bitcoin`
--
ALTER TABLE `transaksi_litecoin_bitcoin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_litecoin_bitcoin_done`
--
ALTER TABLE `transaksi_litecoin_bitcoin_done`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_litkoin_bitcoin`
--
ALTER TABLE `transaksi_litkoin_bitcoin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_litkoin_bitcoin_done`
--
ALTER TABLE `transaksi_litkoin_bitcoin_done`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_tele_bitcoin`
--
ALTER TABLE `transaksi_tele_bitcoin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaksi_tele_bitcoin_done`
--
ALTER TABLE `transaksi_tele_bitcoin_done`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
