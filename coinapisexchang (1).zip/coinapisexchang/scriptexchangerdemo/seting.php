<?php
$codeapi = ""; // dapatkan code ini pada coinapis.com
$masterbitcoin = ""; //setingan untuk otomatis wd
$masterdogecoin = ""; //setingan untuk otomatis wd
$masterlitecoin = ""; //setingan untuk otomatis wd
$mastertellecoin = ""; //setingan untuk otomatis wd
$masterlitkoin = ""; //setingan untuk otomatis wd
?>