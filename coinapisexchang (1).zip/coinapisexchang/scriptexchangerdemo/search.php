<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();
 
 $judul=$_POST["judul"];

 if($judul == 'help'){
	   $result=mysql_query("SELECT * FROM faq");
?>

					<section class="faq-page-questions">
					<div class="row">
					<div class="col-md-12">
<?php
	 $i = 0;
    while($row=mysql_fetch_array($result)){
    $i++;
	?>
				
							<article class="faq-page-quest">
								<header class="faq-page-quest-title">
									<h3><?php echo $i.". ".$row['pertanyaan']; ?></h3>
								</header>
								<?php echo $row['jawaban']; ?>
							</article>
							<hr>
					
							
	<?php
    } 
?>
</div>
					</div>
					</section>
<?php	
 }else{
	 

 
	 ?>
	 <section class="faq-page-questions">
	 <div class="row">
					<div class="col-md-12">
	 <?php
	 $result=mysql_query("SELECT * FROM faq where pertanyaan like '%$judul%'");
	 $found = mysql_num_rows($result);
 if($found>0){
	 $i = 0;
    while($row=mysql_fetch_array($result)){
    $i++;
	?>
				
					
							<article class="faq-page-quest">
								<header class="faq-page-quest-title">
									<h3><?php echo $i.". ".$row['pertanyaan']; ?></h3>
								</header>
								<?php echo $row['jawaban']; ?>
							</article>
							<hr>
							
	<?php
    }   
 }else{
    ?>
	<center><b>Tidak ada pertanyaan yang ditemukan</b></center>
 <?php
 }
 
 }
?>

</div>
					</div>