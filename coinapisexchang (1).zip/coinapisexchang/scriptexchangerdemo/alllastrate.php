<?php
session_start();
//error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$now = date("Y-m-d");

//transaksiterakhir
$transaksiterakhirdogecoin = mysql_query("select * from transaksi_doge_bitcoin_done order by id desc");
$transaksiterakhirdogecoindogecoin = mysql_fetch_array($transaksiterakhirdogecoin);
//tertinggi
$tertinggidogecoin = mysql_query("select * from transaksi_doge_bitcoin_done where tanggaljam like '%$now%' order by rate desc");
$tertinggidogecoindogecoin = mysql_fetch_array($tertinggidogecoin);
//terendah
$terendahdogecoin = mysql_query("select * from transaksi_doge_bitcoin_done where rate != '0' and tanggaljam like '%$now%' order by rate asc");
$terendahdogecoindogecoin = mysql_fetch_array($terendahdogecoin);
				
				
				
//transaksiterakhir
$transaksiterakhirlitecoin = mysql_query("select * from transaksi_litecoin_bitcoin_done order by id desc");
$transaksiterakhirlitecoinlitecoin = mysql_fetch_array($transaksiterakhirlitecoin);
//tertinggi
$tertinggilitecoin = mysql_query("select * from transaksi_litecoin_bitcoin_done where tanggaljam like '%$now%' order by rate desc");
$tertinggilitecoinlitecoin = mysql_fetch_array($tertinggilitecoin);
//terendah
$terendahlitecoin = mysql_query("select * from transaksi_litecoin_bitcoin_done where rate != '0' and tanggaljam like '%$now%' order by rate asc");
$terendahlitecoinlitecoin = mysql_fetch_array($terendahlitecoin);
				
				
				
//transaksiterakhir
$transaksiterakhirtellecoin = mysql_query("select * from transaksi_tele_bitcoin_done order by id desc");
$transaksiterakhirtellecointellecoin = mysql_fetch_array($transaksiterakhirtellecoin);

//tertinggi
$tertinggitellecoin = mysql_query("select * from transaksi_tele_bitcoin_done where tanggaljam like '%$now%' order by rate desc");
$tertinggitellecointellecoin = mysql_fetch_array($tertinggitellecoin);
//terendah
$terendahtellecoin = mysql_query("select * from transaksi_tele_bitcoin_done where rate != '0' and tanggaljam like '%$now%' order by rate asc");
$terendahtellecointellecoin = mysql_fetch_array($terendahtellecoin);
				
				
				
//transaksiterakhir
$transaksiterakhirlitkoin = mysql_query("select * from transaksi_litkoin_bitcoin_done order by id desc");
$transaksiterakhirlitkoinlitkoin = mysql_fetch_array($transaksiterakhirlitkoin);
//tertinggi
$tertinggilitkoin = mysql_query("select * from transaksi_litkoin_bitcoin_done where tanggaljam like '%$now%' order by rate desc");
$tertinggilitkoinlitkoin = mysql_fetch_array($tertinggilitkoin);
//terendah
$terendahlitkoin = mysql_query("select * from transaksi_litkoin_bitcoin_done where rate != '0' and tanggaljam like '%$now%' order by rate asc");
$terendahlitkoinlitkoin = mysql_fetch_array($terendahlitkoin);
				
				
				
				
?>
<center>
<div style='min-height:430; max-height:430px;overflow:auto;'>
<?php
if ($terendahdogecoindogecoin['rate'] == "" AND $terendahlitecoinlitecoin['rate'] == "" AND $terendahtellecointellecoin['rate'] == "" AND $terendahlitkoinlitkoin['rate'] == "")
{
	
	echo "Belum ada transaksi samasekali";
	?>
	<br>
	<br>
		
		
		
	<button type="text" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-doge'" >
	<img src='./img/bitcoin.png' width='30' height='30'> 
	<span class="font-icon font-icon-refresh"></span>
	<img src='./img/dogecoin.png' width='30' height='30'>
	</button>	
	
		<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-litecoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/litecoin.png' width='30' height='30'>
			</button>
			
			<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/tele-bitcoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/tellecoin.png' width='30' height='30'>
			</button>
		
		<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-litkoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/litkoin.png' width='80' height='30'>
			</button>

	<?php
}
else 
{
?>

		<?php
		if ($transaksiterakhirdogecoindogecoin['rate'] == "")
		{
			?>
			<button type="text" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-doge'" >
			<img src='./img/bitcoin.png' width='30' height='30'> 
			<span class="font-icon font-icon-refresh"></span>
			<img src='./img/dogecoin.png' width='30' height='30'>
			</button>
			<br>
			<?php
			
		}
		else
		{
		?>
		<table onclick="window.location='trade/bitcoin-doge'" >
		<td width='100%' colspan='3' align='center'>
		<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in"><span class="font-icon font-icon-refresh"></span></span> 
		<img src='./img/dogecoin.png' width='30' height='30'>
		</td>
		<tr>
		<td width='50%'>Harga Terakhir</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $transaksiterakhirdogecoindogecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Tertinggi</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $tertinggidogecoindogecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Terendah</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $terendahdogecoindogecoin['rate']; ?></td>
		</tr>
		</table>
		<?php
		}
		?>
		<br>



		<?php
		if ($transaksiterakhirlitecoinlitecoin['rate'] == "")
		{
			?>
			<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-litecoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/litecoin.png' width='30' height='30'>
			</button>
			<br>
			<?php
			

		}
		else
		{
		?>
		<table onclick="window.location='trade/tele-bitcoin'" >
		<td width='100%' colspan='3' align='center'>
		<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in"><span class="font-icon font-icon-refresh"></span></span> 
		<img src='./img/litecoin.png' width='30' height='30'>
		</td>
		<tr>
		<td width='50%'>Harga Terakhir</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $transaksiterakhirlitecoinlitecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Tertinggi</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $tertinggilitecoinlitecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Terendah</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $terendahlitecoinlitecoin['rate']; ?></td>
		</tr>
		</table>
		<?php
		}
		?>
		<br>



		<?php
		
		if ($transaksiterakhirtellecointellecoin['rate'] == "")
		{
			?>			
			<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/tele-bitcoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/tellecoin.png' width='30' height='30'>
			</button>
			<br>
			<?php
			

		}
		else
		{
		?>
		<table onclick="window.location='trade/tele-bitcoin'" >
		<td width='100%' colspan='3' align='center'>
		<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in"><span class="font-icon font-icon-refresh"></span></span> 
		<img src='./img/tellecoin.png' width='30' height='30'>
		</td>
		<tr>
		<td width='50%'>Harga Terakhir</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $transaksiterakhirtellecointellecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Tertinggi</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $tertinggitellecointellecoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Terendah</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $terendahtellecointellecoin['rate']; ?></td>
		</tr>
		</table>
		<?php
		}
		?>
		<br>



		<?php
		if ($transaksiterakhirlitkoinlitkoin['rate'] == "")
		{
			?>
			<button type="button" class="btn btn-inline btn-primary-outline col-sm-12" onclick="window.location='trade/bitcoin-litkoin'" >
			<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in">
			<span class="font-icon font-icon-refresh"></span></span> 
			<img src='./img/litkoin.png' width='80' height='30'>
			</button>
			<br>
			<?php
			

		}
		else
		{
		?>
		<table onclick="window.location='trade/tele-bitcoin'" >
		<td width='100%' colspan='3' align='center'>
		<img src='./img/bitcoin.png' width='30' height='30'> <span class="nav-link-in"><span class="font-icon font-icon-refresh"></span></span> 
		<img src='./img/litkoin.png' width='50' height='30'>
		</td>
		<tr>
		<td width='50%'>Harga Terakhir</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $transaksiterakhirlitkoinlitkoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Tertinggi</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $tertinggilitkoinlitkoin['rate']; ?></td>
		</tr>

		<tr>
		<td width='50%'>Terendah</td>
		<td width='10%'>:</td>
		<td width='40%'><?php echo $terendahlitkoinlitkoin['rate']; ?></td>
		</tr>
		</table>
		<?php
		}
		?>
		<br>


<?php
}
?>



</center>