<?php
//error_reporting(0);
ini_set('memory_limit', '256M');
//echo '<pre>'; print_r($_SESSION); die();
include('koneksi.php');
$conn = new Connection();
$conn->connOpen();
//tangkap data dari form
$password1 = md5($_POST['password1']);
$password2 = md5($_POST['password2']);
if($_POST['leader'] == ''){
$leader = 'admin@yourdomainname.com';
}else{
$leader = $_POST['leader'];
}
$nama = $_POST['nama'];
$email = $_POST['email'];
$nohp = $_POST['nohp'];
$cek_email=mysql_num_rows(mysql_query("SELECT email FROM users WHERE email='$email'"));
$cek_nohp = mysql_num_rows(mysql_query("select * from users where nohp = '$nohp'"));
$cek_user = mysql_num_rows(mysql_query("select * from users"));
if (!preg_match("/^[a-zA-Z ]*$/",$nama)) {
header('location:daftar?gagal=6');
break;
}	
if($password1 != $password2){
header("location:daftar?gagal=1");
}else if($cek_email != 0){
header("location:daftar?gagal=2");
}else if($cek_nohp != 0){
header("location:daftar?gagal=3");
}else if($nama == '' or $email == '' or $nohp == ''){
header('location:daftar?gagal=4');
}else{
$no = $cek_user + 1;
$iduser = "code$no";
$tambah = mysql_query("INSERT INTO `users` (`id`, `iduser`, `leader`, `email`, `password`, `nama`, `nohp`, `tanggaljam`,`blokir`) 
VALUES (NULL, '$iduser', '$leader', '$email', '$password2', '$nama', '$nohp', CURRENT_TIMESTAMP,'0');");
header('location:masuk?sukses=1');
}
?>