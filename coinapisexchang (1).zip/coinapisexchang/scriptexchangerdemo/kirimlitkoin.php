<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$litkoin = $_POST['litkoin'];
$alamat = $_POST['alamat'];



$cekuser = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
$cek = mysql_fetch_array($cekuser);

if($litkoin >= 10){

if($cek['saldolitkoin'] >= $litkoin){

$total = $litkoin - 5;
$sisasaldo = $cek['saldolitkoin']-$litkoin;

$update = mysql_query("update users set saldolitkoin = '$sisasaldo' where iduser = '$_SESSION[iduser]'");

$query2 = mysql_query("INSERT INTO `riwayattx` (`id`, `iduser`, `jenis`, `matauang`, `nominal`, `status`, `tanggaljam`) VALUES (NULL, '$_SESSION[iduser]', 'kirim', 'litkoin', '$litkoin', 'Kirim litkoin Ke $alamat , Nominal : $litkoin', CURRENT_TIMESTAMP);");

	
header('location:transaksi.php?sukses=2');

}else{
	
header('location:transaksi.php?gagal=2');

}

}else{
	
	header('location:transaksi.php?gagal=3');
}


?>