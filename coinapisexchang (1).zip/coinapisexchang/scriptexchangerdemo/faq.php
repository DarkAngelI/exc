<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<link rel="icon" type="image/png" href="img/logo-mini.png">
<title>judul situs</title>

<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
<link href="img/favicon.png" rel="icon" type="image/png">
<link href="img/favicon.ico" rel="shortcut icon">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" href="css/separate/pages/others.min.css">
<link rel="stylesheet" href="css/lib/font-awesome/font-awesome.min.css">
<link rel="stylesheet" href="css/lib/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="css/main.css">

</head>
<body>

<?php
	include "header.php";
?>


<div class="page-content">
	<div class="container-fluid">
		<section class="box-typical faq-page">
			<div class="faq-page-header-search">
				<div class="search">
					<input type="text" id="search" class="form-control form-control-rounded" placeholder='Ketik "help" untuk melihat semua bantuan yang ada'/>
					<button type="button" id="button" class="find">
						<i class="font-icon font-icon-search"></i>
					</button>
				</div>
			</div><!--.faq-page-header-search-->

			<section class="faq-page-cats">
				<div class="row">
					<div class="col-md-4">
						<div class="faq-page-cat">
							<div class="faq-page-cat-icon"><img src="img/faq-1.png" alt=""></div>
							<div class="faq-page-cat-title">
								<a href="#">Petunjuk Memulai</a>
							</div>
							<div class="faq-page-cat-txt">Cara Kerja yourdomainname.com</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="faq-page-cat">
							<div class="faq-page-cat-icon"><img src="img/faq-2.png" alt=""></div>
							<div class="faq-page-cat-title">
								<a href="#">Punya Pertanyaan?</a>
							</div>
							<div class="faq-page-cat-txt">Sejumlah pertanyaan yang sering diajukan</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="faq-page-cat">
							<div class="faq-page-cat-icon"><img src="img/faq-3.png" alt=""></div>
							<div class="faq-page-cat-title">
								<a href="#">Saran Pengembangan</a>
							</div>
							<div class="faq-page-cat-txt">Pengembangan website agar lebih baik lagi</div>
						</div>
					</div>
				</div><!--.row-->
			</section><!--.faq-page-cats-->
			
			
				<span id="result"></span>
				
				
			</section><!--.faq-page-questions-->
		</section><!--.faq-page-->
	</div><!--.container-fluid-->
</div><!--.page-content-->

	<script type="text/javascript">
		$(document).ready(function(){
			 
			 function search(){

				  var judul=$("#search").val();

				  if(judul!=""){
					$("#result").html("<br><br><center><img src='ajax-loader.gif'/></center><br><br>");
					 $.ajax({
						type:"post",
						url:"search.php",
						data:"judul="+judul,
						success:function(data){
							$("#result").html(data);
							$("#search").val("");
						 }
					  });
				  }
				  

				 
			 }

			  $("#button").click(function(){
				 search();
			  });

			  $('#search').keyup(function(e) {
				 if(e.keyCode == 13) {
					search();
				  }
			  });
		});
	</script>
<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/tether/tether.min.js"></script>
<script src="js/lib/bootstrap/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/lib/slick-carousel/slick.min.js"></script>


</script>
<script>
	$(function () {
		$(".profile-card-slider").slick({
			slidesToShow: 1,
			adaptiveHeight: true,
			prevArrow: '<i class="slick-arrow font-icon-arrow-left"></i>',
			nextArrow: '<i class="slick-arrow font-icon-arrow-right"></i>'
		});

		var postsSlider = $(".posts-slider");

		postsSlider.slick({
			slidesToShow: 4,
			adaptiveHeight: true,
			arrows: false,
			responsive: [
				{
					breakpoint: 1700,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 1350,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 500,
					settings: {
						slidesToShow: 1
					}
				}
			]
		});

		$('.posts-slider-prev').click(function(){
			postsSlider.slick('slickPrev');
		});

		$('.posts-slider-next').click(function(){
			postsSlider.slick('slickNext');
		});

		/* ==========================================================================
		 Recomendations slider
		 ========================================================================== */

		var recomendationsSlider = $(".recomendations-slider");

		recomendationsSlider.slick({
			slidesToShow: 4,
			adaptiveHeight: true,
			arrows: false,
			responsive: [
				{
					breakpoint: 1700,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 1350,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 500,
					settings: {
						slidesToShow: 1
					}
				}
			]
		});

		$('.recomendations-slider-prev').click(function() {
			recomendationsSlider.slick('slickPrev');
		});

		$('.recomendations-slider-next').click(function(){
			recomendationsSlider.slick('slickNext');
		});
	});
</script>

<script>
document.getElementById("copyButton").addEventListener("click", function() {
copyToClipboard(document.getElementById("copyTarget"));
});

function copyToClipboard(elem) {
  // create hidden text element, if it doesn't already exist
var targetId = "_hiddenCopyText_";
var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
var origSelectionStart, origSelectionEnd;
if (isInput) {
	// can just use the original source element for the selection and copy
	target = elem;
	origSelectionStart = elem.selectionStart;
	origSelectionEnd = elem.selectionEnd;
} else {
	// must use a temporary form element for the selection and copy
	target = document.getElementById(targetId);
	if (!target) {
		var target = document.createElement("textarea");
		target.style.position = "absolute";
		target.style.left = "-9999px";
		target.style.top = "0";
		target.id = targetId;
		document.body.appendChild(target);
	}
	target.textContent = elem.textContent;
}
// select the content
var currentFocus = document.activeElement;
target.focus();
target.setSelectionRange(0, target.value.length);

// copy the selection
var succeed;
try {
	  succeed = document.execCommand("copy");
} catch(e) {
	succeed = false;
}
// restore original focus
if (currentFocus && typeof currentFocus.focus === "function") {
	currentFocus.focus();
}

if (isInput) {
	// restore prior selection
	elem.setSelectionRange(origSelectionStart, origSelectionEnd);
} else {
	// clear temporary content
	target.textContent = "";
}
return succeed;
}




document.getElementById("copyButton2").addEventListener("click", function() {
copyToClipboard(document.getElementById("copyTarget2"));
});

function copyToClipboard(elem) {
  // create hidden text element, if it doesn't already exist
var targetId = "_hiddenCopyText_";
var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
var origSelectionStart, origSelectionEnd;
if (isInput) {
	// can just use the original source element for the selection and copy
	target = elem;
	origSelectionStart = elem.selectionStart;
	origSelectionEnd = elem.selectionEnd;
} else {
	// must use a temporary form element for the selection and copy
	target = document.getElementById(targetId);
	if (!target) {
		var target = document.createElement("textarea");
		target.style.position = "absolute";
		target.style.left = "-9999px";
		target.style.top = "0";
		target.id = targetId;
		document.body.appendChild(target);
	}
	target.textContent = elem.textContent;
}
// select the content
var currentFocus = document.activeElement;
target.focus();
target.setSelectionRange(0, target.value.length);

// copy the selection
var succeed;
try {
	  succeed = document.execCommand("copy");
} catch(e) {
	succeed = false;
}
// restore original focus
if (currentFocus && typeof currentFocus.focus === "function") {
	currentFocus.focus();
}

if (isInput) {
	// restore prior selection
	elem.setSelectionRange(origSelectionStart, origSelectionEnd);
} else {
	// clear temporary content
	target.textContent = "";
}
return succeed;
}
</script>
<script src="js/app.js"></script>
</body>
</html>