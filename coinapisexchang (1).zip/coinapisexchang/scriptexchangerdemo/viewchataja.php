	<script src="jquery.min.js"></script>
				<script>
															$(document).ready(function() {
															$("#chataja").load("chataja.php");
															var refreshId = setInterval(function() 
															{
															$("#chataja").load('chataja.php?randval='+ Math.random());
															}, 1000);
															});
														</script>
														<span id="chataja"></span>
