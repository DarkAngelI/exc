<?php
	
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();


$id = $_GET['id'];

$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
$data = mysql_fetch_array($query);

if($data['level'] != 'admin'){
	header('location:keluar.php');
}else{
	
	$sql = mysql_query("select * from kirimmrai where id = '$id'");
	$row = mysql_fetch_array($sql);
	
	$cek = mysql_query("select * from users where iduser = '$row[iduser]'");
	$c = mysql_fetch_array($cek);
	
	$saldo = $c['saldomrai'] + $row['nominal']+5;
	
	$update = mysql_query("update users set saldomrai = '$saldo' where iduser = '$row[iduser]'");
	
	$notif = mysql_query("INSERT INTO `notifikasi` (`id`, `iduser`, `pesan`, `tanggaljam`) VALUES (NULL, '$row[iduser]', 'Pengiriman mrai dibatalkan, mohon coba kembali beberapa saat lagi.', CURRENT_TIMESTAMP);");
	
	$del = mysql_query("delete from kirimmrai where id = '$id'");
	
	
	header('location:allmember.php?sukses=1');
	
}

?>