<?php
$chat_datafile = "chataja.php";
$chat_postlimit = 100;	// Maximum number of chat entries to store in the chat file
$chat_timelimit = 6;	// Minimum delay in seconds between posts from the same IP
$chat_maxline = 100;	// Maximum number of characters in a post
$chat_refresh = 5;		// Chat content refresh speed, in seconds (can be decimals)
?>