<?php

require('chatconfig1.php');

session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

if(isset($_GET['lastfetch']) && is_numeric($_GET['lastfetch']) && $_GET['lastfetch']>0)
{
	$lastfetch = 0;//round($_GET['lastfetch']);
}
else
{
	$lastfetch = 0;
}

$fp = @fopen($chat_datafile, "r");
if($fp)
{
	while($line = fgets($fp))
	{
		$line = explode("&&", $line);
		if(count($line)<5) continue;
		if($line[0]>=$lastfetch)
		{
			
			$query = mysql_query("select * from users where nama = '$line[2]'");
			$data = mysql_fetch_array($query);
			
			if($data['status'] == 'exchanger'){
				?>
				<div class="chat_line" style="margin-left:10px;"><b><?php echo $line[1]." "; ?></b><span class="chat_user3"><?php echo $line[2]; ?></span>
	<?php
	echo $line[3];
	?>
	</div>
				<?php
			}else if($data['status'] == 'leader'){
	?>
	<div class="chat_line" style="margin-left:10px;"><b><?php echo $line[1]." "; ?></b><span class="chat_user2"><?php echo $line[2]; ?></span>
	<?php
	echo $line[3];
	?>
	</div>
	<?php
			}else if($data['nama'] == 'admin'){
			?>
			
			<div class="chat_line" style="margin-left:10px;"><b><?php echo $line[1]." "; ?></b><span class="chat_user1"><?php echo $line[2]; ?></span>
	<?php
	echo $line[3];
	?>
	</div>
			
			<?php
			}else{
	?>
	<div class="chat_line" style="margin-left:10px;"><b><?php echo $line[1]." "; ?></b><span class="chat_user"><?php echo $line[2]; ?></span>
	<?php
	echo $line[3];
	?>
	</div>
	
	<?php
		}
	}
	}
	fclose($fp);
	

}

?>