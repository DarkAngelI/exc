<?php

session_start();
error_reporting(0);
include('koneksi.php');
$conn = new Connection();
$conn->connOpen();
?>

<?php
$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
$data = mysql_fetch_array($query);
?>
<input type="text" class="form-control" value="<?php echo $data['saldolitkoin']; ?>" style="margin-top:-35px;" disabled />
<?php
$conn->connClose();
?>
			