<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

if($_SESSION['iduser'] == NULL){
		 header("location:masuk.php");
	}
	
	
	$cek = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
	$c = mysql_fetch_array($cek);
	
	if($c['level'] != 'admin'){
		header('location:keluar.php');
	}
?>
<table id="table-xs" class="table table-bordered table-hover table-xs" style="font-size:8pt">
			
				<thead>
				<tr>
					<th width="1">
						<center>#</center>
					</th>
					<th><center>LEADER</center></th>
					<th><center>NAMA</center></th>
					<th><center>EMAIL</center></th>
					<th><center>NOHP</center></th>
					<th><center>ALAMAT MRAI </center></th>
					<th><center>MRAI </center></th>
					<th><center>SALDO </center></th>
					<th><center>AKSI </center></th>
				</tr>
				</thead>
				<tbody>
				<?php
					$i = 0;
					$query = mysql_query("select * from users inner join depth on depth.alamatdompet = users.alamatdompet where balance  > '0' order by depth.balance desc");
					while($data = mysql_fetch_array($query)){
						$i++;
				?>
				<tr>
					<td><center><?php echo $i; ?></center></td>
					<td><center><?php echo strtolower($data['leader']); ?></center></td>
					<td><center><?php echo ucfirst(strtolower($data['nama'])); ?></center></td>
					<td><center><?php echo strtolower($data['email']); ?></center></td>
					<td><center><?php echo $data['nohp']; ?></center></td>
					<td><center><?php echo $data['alamatdompet']; ?></center></td>
					<td><center><?php echo $data['balance']; ?></center></td>
					<td><center><?php echo $data['saldomrai']; ?></center></td>
					<?php
						$now = date("Y-m-d");
						$cekhistory = mysql_query("select * from `historymrai` where iduser = '$data[iduser]' and `tanggaljam` LIKE '%$now%'");
						$ck = mysql_num_rows($cekhistory);
						
						if($ck == 0){
					?>
					<td><center><a class="btn btn-nav btn-rounded btn-inline btn-primary-outline" onclick="return confirm('Apakah anda yakin akan input saldo?')" href="inputsaldo.php?wallet=<?php echo $data['alamatdompet']; ?>&balance=<?php echo $data['balance']; ?>">Input</a></center></td>
					<?php
						}else{
					?>
					<td></td>
					<?php
						}
					?>
				</tr>
				<?php
					}
				?>
				</tbody>
			</table>