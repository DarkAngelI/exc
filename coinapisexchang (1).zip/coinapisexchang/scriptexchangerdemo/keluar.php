<?php

ini_set('display_errors', 0);

ini_set('log_errors', 1);




session_start();

session_destroy();

	$_SESSION['iduser'] = $data['iduser'];

	$_SESSION['alamatdompet'] = $data['alamatdompet'];





echo "<script>window.location = 'masuk'</script>";

?>