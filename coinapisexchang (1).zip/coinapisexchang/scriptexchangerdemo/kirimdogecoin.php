<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$dogecoin = $_POST['dogecoin'];
$alamat = $_POST['alamat'];



$cekuser = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
$cek = mysql_fetch_array($cekuser);

if($dogecoin >= 10){

if($cek['saldodogecoin'] >= $dogecoin){

$total = $dogecoin - 5;
$sisasaldo = $cek['saldodogecoin']-$dogecoin;

$update = mysql_query("update users set saldodogecoin = '$sisasaldo' where iduser = '$_SESSION[iduser]'");

$query2 = mysql_query("INSERT INTO `riwayattx` (`id`, `iduser`, `jenis`, `matauang`, `nominal`, `status`, `tanggaljam`) VALUES (NULL, '$_SESSION[iduser]', 'kirim', 'dogecoin', '$dogecoin', 'Kirim dogecoin Ke $alamat , Nominal : $dogecoin', CURRENT_TIMESTAMP);");

	
header('location:transaksi.php?sukses=2');

}else{
	
header('location:transaksi.php?gagal=2');

}

}else{
	
	header('location:transaksi.php?gagal=3');
}


?>