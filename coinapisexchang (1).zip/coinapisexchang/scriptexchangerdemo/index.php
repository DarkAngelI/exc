<?php
echo "
<h1>Edit Sendiri</h1>
<br>link masuk 
<a href='masuk'>Masuk</a>
<br>link daftar
<a href='daftar'>Daftar</a>
";
?>