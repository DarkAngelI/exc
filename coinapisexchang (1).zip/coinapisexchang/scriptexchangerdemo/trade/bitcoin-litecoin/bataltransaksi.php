<?php
session_start();
error_reporting(0);
include('../../koneksi.php');
include "./seting.php";
$conn = new Connection();
$conn->connOpen();
	function format_rupiah($angka){
	$rupiah=number_format($angka,0,',','.');
	return $rupiah;
	}
	if($_SESSION['iduser'] == NULL){
		 header("location:masuk");
	}else{
		$id = $_GET['id'];
		$cektransaksi = mysql_query("select * from $databasetransaksi where id = '$id' and iduser = '$_SESSION[iduser]'");
		$cektransaksi2 = mysql_fetch_array($cektransaksi);
		
		if($cektransaksi2['jenis'] == 'JUAL'){
			$sisalitecoin = $cektransaksi2['jumlah'];
			$update = mysql_query("update users set saldolitecoin = saldolitecoin+'$sisalitecoin' where iduser = '$_SESSION[iduser]'");
			$query= mysql_query("delete from $databasetransaksi where iduser = '$_SESSION[iduser]' and id = '$id'");
		}
		else if($cektransaksi2['jenis'] == 'BELI'){
			$sisabitcoin = $cektransaksi2['total'];
			$update = mysql_query("update users set saldobitcoin = saldobitcoin+'$sisabitcoin' where iduser = '$_SESSION[iduser]'");
			$query= mysql_query("delete from $databasetransaksi where iduser = '$_SESSION[iduser]' and id = '$id'");
		}
		header('location:index?sukses=5');
		}	
?>