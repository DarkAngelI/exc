<?phpsession_start();error_reporting(0);include('../../koneksi.php');$cekonn = new Connection();$cekonn->connOpen();$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");$data = mysql_fetch_array($query);	function format_rupiah($angka){	$rupiah=number_format($angka,0,',','.');	return $rupiah;	}	if($_SESSION['iduser'] == NULL){		 header("location:masuk");	}else{	$rate = $_POST['rate'];	$totalnya = $_POST['totalnya'];	$password = md5($_POST['password']);		if($rate != 0)		{				if($totalnya < 10)					{					header("location:index?gagal=3");					}					else{					$cekekpass = mysql_query("select * from users where iduser = '$_SESSION[iduser]' and password = '$password'");					$num = mysql_num_rows($cekekpass);					$data = mysql_fetch_array($cekekpass);					if($num == 1){						$total = $rate*$totalnya;						$tanggal = date("Y-m-d h:i:sa");						$sha1 = sha1("$tanggal");						//cek saldo rate lebih banyak						if($data['saldobitcoin'] >= $total)						{							$beli = mysql_query("INSERT INTO `transaksi_tele_bitcoin` (`id`, `iduser`, `jenis`, `hash`, `rate`, `jumlah`, `total`, `tanggaljam`, `status`)							VALUES (NULL, '$_SESSION[iduser]', 'BELI', '$sha1', '$rate', '$totalnya', '$total', CURRENT_TIMESTAMP, 'pending');");							$sisabitcoin = $data['saldobitcoin'] - $total;							$updatebitcoin = mysql_query("update users set saldobitcoin = '$sisabitcoin' where iduser = '$_SESSION[iduser]'");							header("location:index?sukses=1");							}						else							{
							header("location:index?gagal=2");
							}
					}else{
					header("location:index?gagal=1");
					}
					}
		}else{
			header("location:index?gagal=4");
		}
		}
	?>