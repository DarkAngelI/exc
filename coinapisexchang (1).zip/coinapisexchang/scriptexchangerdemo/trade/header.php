<?php
session_start();
error_reporting(0);

//include('cekall.php');
include('../../koneksi.php');
$conn = new Connection();
$conn->connOpen();


function format_rupiah($angka){
$rupiah=number_format($angka,0,',','.');
return $rupiah;
}


//sesionnya kosong

$qquery = mysql_query("select * from users where  iduser = '$_SESSION[iduser]' AND blokir = 1 ");
$asddata = mysql_fetch_array($qquery);


if($asddata['blokir'] == 1){
	header('location:../../masuk');
}
		
?>

<header class="site-header">
    <!--<meta http-equiv="refresh" content="200">-->
	    <div class="container-fluid">
	
	        <a href="../../home" class="site-logo">
	            <img class="hidden-md-down" src="../../img/logo.png" alt="">
	            <img class="hidden-lg-up" src="../../img/logo.png" alt="">
	        </a>
	
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">
	                    
	
	                    
						<?php
							if($_SESSION['iduser'] == NULL){
						?>
						<script src="../../jquery.min.js"></script>
						<div class="dropdown dropdown-typical">
						<a class="dropdown-item" href="faq"><span class="font-icon glyphicon glyphicon-question-sign"></span>Bantuan</a>
						</div>
						<?php
							}
						?>
						<?php
							if($_SESSION['iduser'] != NULL){
						?>
						
				
							
						 <div class="dropdown user-menu">
	                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                            <img src="../../img/avatar-2-64.png" alt="">
	                        </button>
	                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd-user-menu">
	                            <a class="dropdown-item" href="../../home"><span class="font-icon glyphicon glyphicon-user"></span>Profil</a>
	                            <a class="dropdown-item" href="../../transaksi"><span class="font-icon font-icon-event"></span>Deposit/Withdraw</a>
	                            <a class="dropdown-item" href="../../home?pengaturan=1"><span class="font-icon glyphicon glyphicon-cog"></span>Pengaturan</a>
	                            <a class="dropdown-item" href="../../faq"><span class="font-icon glyphicon glyphicon-question-sign"></span>Bantuan</a>
	                            <div class="dropdown-divider"></div>
	                            <a class="dropdown-item" href="../../keluar" id="notie-confirm"><span class="font-icon glyphicon glyphicon-log-out"></span>Logout</a>
	                        </div>
	                    </div>
						<?php
							}
						?>
						
	                   
	
	                    <button type="button" class="burger-right">
	                        <i class="font-icon-menu-addl"></i>
	                    </button>
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    <div class="site-header-collapsed-in">
								<?php
							if($_SESSION['iduser'] != NULL){
						?>
						<?php
							$verifikasi = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
							$v = mysql_fetch_array($verifikasi);
							//if($v['verifikasi'] != 0){
						?>
	                   
	                    
	                    
	                                        
	                    <!--.site-header-collapsed-in-->
						<?php
							//}else{
						?>
						<!--
						<div class="dropdown dropdown-typical">
	                        						<button style="font-size:10pt" id="notie-error" class="btn btn-nav btn-rounded btn-inline btn-primary-outline" type="button" class="btn btn-danger"><span class="font-icon font-icon-revers"></span> Jual/Beli</button>
						</div>
						
						<div class="dropdown dropdown-typical">
	                        						<button style="font-size:10pt" id="notie-error2" class="btn btn-nav btn-rounded btn-inline btn-primary-outline" type="button" class="btn btn-danger"><span class="font-icon font-icon-event"></span> Deposit/Withdraw</button>
						</div>
						-->
						<?php
							//}
						?>
						<?php
							}
						?>
						<?php
							if($_SESSION['iduser'] != NULL){
								
								$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
								$data = mysql_fetch_array($query);
								
						?>
						<div class="dropdown dropdown-typical">
						    
						    
	                        
	         
	                    
	                       
	                        
	                    </div>



<!--.site-header-collapsed-in-->
						<?php
							}else{
						?>
						
						
	                    
	                    
	                                   
	                    
	                    <!--.site-header-collapsed-in-->
						<?php
							}
						?>
						<!--<div class="dropdown dropdown-typical">
	                        <a class="btn btn-nav btn-rounded btn-inline btn-primary-outline" href="top" style="font-size:10pt">
	                            <span class="font-icon font-icon-award"></span> Top
	                        </a>
	                    </div>.site-header-collapsed-in-->
						
						
						<?php
							if($_SESSION['iduser'] == NULL){
						?>
						<div class="dropdown dropdown-typical">
	                        <a class="btn btn-nav btn-rounded btn-inline btn-success-outline" href="masuk" style="font-size:10pt">
	                            <span class="font-icon font-icon-lock"></span> Daftar/Masuk
	                        </a>
	                    </div>
	                    
	                   
	                    
	                    <!--.site-header-collapsed-in-->
						
						
						<?php
							}
						
						?>
						
						
						</div><!--.site-header-collapsed-in-->
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

 <script src="../../js/lib/notie/notie.js"></script>
<script src="../../js/lib/notie/notie-init.js"></script>


<script src="../../jquery.min.js"></script>