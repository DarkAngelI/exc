<?phpsession_start();error_reporting(0);
include('../../koneksi.php');include "./seting.php";
$conn = new Connection();
$conn->connOpen();
if($_SESSION['iduser'] == NULL){
		 header("location:masuk.php");
	}
?>
<div style="overflow-x:auto;">
				<table id="table-xs" class="table table-bordered table-hover table-xs">
				<thead>
				<tr>
					<th>RATE</th>
					<th>JUMLAH</th>					<th>TOTAL BTC</th>
					<th>TANGGAL</th>
				</tr>
				</thead>
				<tbody>
				<?php				$query = mysql_query("SELECT `rate`,`total`,`tanggaljam`, SUM(`jumlah`) as jumlahcoin FROM $databasetransaksi WHERE jenis = 'JUAL' AND status = 'pending' GROUP BY `rate` ORDER BY `rate` ASC");			$nums = mysql_num_rows($query);
					if($nums != 0){
					while($data = mysql_fetch_array($query)){
				?>
				<tr>
					<td><?php echo $data['rate']; ?></td>
					<td><?php echo $data['jumlahcoin']; ?></td>					<td><?php echo $data['total'];?></td>
					<td><?php echo $data['tanggaljam']; ?></td>
				</tr>
				<?php
					}
					}else{
					?>
					<tr>
						<td colspan="3"><center>Tidak Ada Data</center></td>
					</tr>
					<?php
					}
					?>
				</tbody>
			</table>
			</div>