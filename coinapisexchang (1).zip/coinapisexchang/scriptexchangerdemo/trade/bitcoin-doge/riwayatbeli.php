<?php
session_start();
error_reporting(0);
include('../../koneksi.php');
include "./seting.php";
$conn = new Connection();
$conn->connOpen();
?>
					<table id="table-xs" class="table table-bordered table-hover table-xs">
				<thead>
				<tr>
					<th><center>RATE</center></th>
					<th><center>JUMLAH</center></th>
					<th><center>TOTAL BTC</center></th>
					<th><center>TANGGAL</center></th>
				</tr>
				</thead>
				<tbody>
				<?php
					$i = 0;
					$query = mysql_query("select * from $databasetransaksidone where jenis = 'BELI' order by id desc limit 20");
					$nums = mysql_num_rows($query);
					if($nums != 0){
					while($data = mysql_fetch_array($query)){
				?>
				<tr>
					<td><center><?php echo $data['rate']; ?></center></td>
					<td><center><?php echo $data['jumlah']; ?></center></td>
					<td><center><?php echo $data['total']; ?></center></td>
					<td><center><?php echo $data['tanggaljam']; ?></center></td>
				</tr>
				<?php
					}
					}else{
				?>
				<tr>
					<td colspan="4"><center>Tidak Ada Data</center></td>
				</tr>
				<?php
					}
				?>
				</tbody>
			</table>