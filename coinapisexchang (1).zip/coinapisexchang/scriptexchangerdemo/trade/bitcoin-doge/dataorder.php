<?php
session_start();
error_reporting(0);
include('../../koneksi.php');
include "seting.php";
$conn = new Connection();
$conn->connOpen();
?>
<div style="overflow-x:auto;">
						<table id="table-xs" class="table table-bordered table-hover table-xs">
				<thead>
				<tr>
					<th>JENIS</th>					<th>RATE</th>
					<th>JUMLAH</th>
					<th>TANGGAL</th>
					<th width="120">AKSI</th>
				</tr>
				</thead>
				<tbody>
				<?php 
					$query = mysql_query("select * from $databasetransaksi where iduser = '$_SESSION[iduser]' order by id desc");
					$num = mysql_num_rows($query);
					if($num != 0){
					while($data = mysql_fetch_array($query)){
					?>
				<tr>
					<td><?php echo $data['jenis']; ?></td>
					<td><?php echo $data['rate']; ?></td>
					<td><?php echo $data['jumlah']; ?></td>
					<td><?php echo $data['tanggaljam']; ?></td>
					<td><a href="bataltransaksi?id=<?php echo $data['id']; ?>" onclick="return confirm('Apakah anda yakin akan membatalkan transaksi?')"><button type="button" class="btn btn-rounded btn-inline btn-danger-outline">Batalkan</button><a></td>
				</tr>
				<?php
					}
					}else{
				?>
				<tr>
					<td colspan="5"><center>Tidak Ada Data</center></td>
				</tr>
				<?php
					}
				?>
				</tbody>
			</table>			</div>