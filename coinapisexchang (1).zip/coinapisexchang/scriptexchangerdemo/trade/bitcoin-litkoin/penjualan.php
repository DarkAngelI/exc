<?php
session_start();
error_reporting(0);
include('../../koneksi.php');
include "seting.php";
$conn = new Connection();
$conn->connOpen();
				function format_rupiah($angka){
				  $rupiah=number_format($angka,0,',','.');
				  return $rupiah;
				}
	if($_SESSION['iduser'] == NULL){
		 header("location:masuk");
	}else{
	$rate = $_POST['rate'];
	$jumlahnya = $_POST['jumlahnya'];
	$password = md5($_POST['password']);
	if($rate != 0){
	if($jumlahnya < '10'){
		header("location:index?gagal=3");
	}else{
	$cekpass = mysql_query("select * from users where iduser = '$_SESSION[iduser]' and password = '$password'");
	$num = mysql_num_rows($cekpass);
	$data = mysql_fetch_array($cekpass);
	if($num == 1)
	{
		if($data["saldolitkoin"] >= $jumlahnya)
		{	$total = $rate*$jumlahnya;
			$tanggal = date("Y-m-d h:i:sa");
			$sha1 = sha1("$tanggal");
			$sisalitkoin = $data["saldolitkoin"] - $jumlahnya;		
			$jual = mysql_query("INSERT INTO `$databasetransaksi` (`id`, `iduser`, `jenis`, `hash`, `rate`, `jumlah`, `total`, `tanggaljam`, `status`) 
			VALUES (NULL, '$_SESSION[iduser]', 'JUAL','$sha1', '$rate', '$jumlahnya', '$total', CURRENT_TIMESTAMP, 'pending');");
			$updatelitkoin = mysql_query("update users set saldolitkoin = '$sisalitkoin' where iduser = '$_SESSION[iduser]'");
			header("location:index?sukses=2");
		}
						else
							{
							header("location:index?gagal=2");
							}
					}else{
					header("location:index?gagal=1");
					}
					}
		}else{
			header("location:index?gagal=4");
		}
		}

	?>