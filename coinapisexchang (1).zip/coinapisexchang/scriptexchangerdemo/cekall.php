<?php
/*
$cekurl1 = $_SERVER['HTTP_HOST'];

if ($cekurl1 == "yourdomainname.com" ){
}
else {
    echo "<script>window.location = 'https://localhost/scriptexchanger/masuk?gagal=4'</script>";
}
*/
?>

<script type="text/javascript">

var self = self.location;
var top = top.location;
var parent = parent.location;
var window = window.location;

if (top != self || parent != self || window != self  )
window = self;
</script> 

