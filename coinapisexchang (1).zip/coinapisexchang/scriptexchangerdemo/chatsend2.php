<?php

require('chatconfig2.php');

// Check for a valid username and message
$valid_data = true;
if(!isset($_POST['username']) || !isset($_POST['message']) || preg_match('/^[a-z0-9_\-\.\s]{3,12}$/i',$_POST['username'])===false || strlen($_POST['message'])<1 || strlen($_POST['message'])>$chat_maxline)
{
	$valid_data = false;
}
else
{
	date_default_timezone_set('Asia/Jakarta');
	$time = "[".date('Y-m-d')."] ";
	$username = $_POST['username'];
	$message = htmlspecialchars($_POST['message']);
}

if($valid_data)
{
	// Check the last post by this user
	$fp = @fopen($chat_datafile, "r");
	if($fp)
	{
		$can_post = true;
		
		while($line = @fgets($fp))
		{
			$line = explode("&&", $line);
			if($line[4]==$_SERVER['REMOTE_ADDR'] && $line[0]>=(time()-$chat_timelimit))
			{
				$can_post = false;
				break;
			}
		}
		
		// If the user can post, check there aren't too many saved
		// entries then push onto the end of the stack
		if($can_post)
		{
			rewind($fp);
			$output = array();
			
			$linecount = 0;
			
			while($line = @fgets($fp))
			{
				$linecount++;
				array_push($output, $line);
				if($linecount>=$chat_postlimit)
				{
					array_shift($output);
					$linecount--;
				}
			}
			
			array_push($output, time()."&&{$time}&&{$username}&&{$message}&&{$_SERVER['REMOTE_ADDR']}\n");

include("koneksi.php");
$conn = new Connection();
$conn->connOpen();

if ($username != "" AND $message != ""){
$tambah = mysql_query("INSERT INTO `telegram` (`no`, `nama`, `isi`, `tanggal`) VALUES (NULL, '$username', '$message', CURRENT_TIMESTAMP);");
}	

	
			
			fclose($fp);
			$fp = fopen($chat_datafile, "w");
			fwrite($fp, join("", $output));
			fclose($fp);
			
			// Success
			die("success");
		}
	}
}

// Failure
die("failed");

$conn->mysql_close();
?>