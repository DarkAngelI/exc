<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$email = $_POST['email'];
$password = md5($_POST['password']);

$query = mysql_query("select * from users where email = '$email' and password = '$password'");
$data = mysql_fetch_array($query);
$num = mysql_num_rows($query);

if (preg_match("/^[a-zA-Z0-9.@_]*$/",$email)) { 
	if($num == 1){	
		if($data['blokir'] != '0'){
			header('location:masuk?gagal=blokir');
			break;
			}
			else{	
			$_SESSION['email'] = $data['email'];
			$_SESSION['iduser'] = $data['iduser'];
			$_SESSION['alamatdompet'] = $data['alamatdompet'];
			$_SESSION['nama']  = $data['nama'];
			header('location:home');
			}
	}
	else{
	header('location:masuk?gagal=1');
	break;
	}
} 

else 
{ 
header('location:masuk?gagal=2');
}

?>