<style>
adminya {
   color: red;
}




/* Tooltip container */
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black; /* If you want dots under the hoverable text */
}

/* Tooltip text */
.tooltip .tooltiptext {
    visibility: hidden;
    width: 200px;
    background-color: #555;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 6px;

    /* Position the tooltip text */
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -60px;

    /* Fade in tooltip */
    opacity: 0;
    transition: opacity 1s;
}

/* Tooltip arrow */
.tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}

/* Show the tooltip text when you mouse over the tooltip container */
.tooltip:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
}


</style>

<?php

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();


?>


			
			
<?php
$i = 0;
$qrqeqwqwdy = mysql_query("Select users.nama, users.status, telegram.no, telegram.nama, telegram.isi, telegram.tanggal, telegram.statusblokir from users, telegram WHERE users.nama = telegram.nama ORDER BY `telegram`.`no` DESC LIMIT 1");
while($data123123 = mysql_fetch_array($qrqeqwqwdy)){
$i++;
$jumlah100 = $data123123['no']-50;
}
?>






<?php
$i = 0;
$qry = mysql_query("Select users.nama, users.status, telegram.no, telegram.nama, telegram.isi, telegram.tanggal, telegram.statusblokir from users, telegram WHERE users.nama = telegram.nama AND telegram.no > $jumlah100 AND statusblokir = '0' ORDER BY `telegram`.`no`");
while($data = mysql_fetch_array($qry)){
$i++;
?>
    
    <?php
    $isi= $data['tanggal'];
    $jamnya = substr($isi, 11,5);
    ?>
    
    <?php
    if($data['status'] == "admin")
    {
	?>
	

	<div style="margin-left:10px;"><?php echo "["; echo $jamnya; echo "] "; ?><b><span style="color:red;" tooltip="Admin Raiblock.co.id">
	<div class="tooltip"><?php echo $data['nama']; ?><span class="tooltiptext">Admin Raiblokc.co.id</span></div>
	</span></b><?php echo " : ";?><span class="chat_user1"><?php echo $data['isi']; ?></span>
	</div>
	<?php
	}
	
	
	else if($data['status'] == "leader"){
	?>
	<div style="margin-left:10px;"><?php echo "["; echo $jamnya; echo "] "; ?><b><span style="color:blue;"><?php echo $data['nama']; ?></span></b><?php echo " : ";?><span class="chat_user1"><?php echo $data['isi']; ?></span>
	</div>
    <?php
	}
		
		
			
	else if($data['status'] == "exchanger"){
	?>
	<div  style="margin-left:10px;"><?php echo "["; echo $jamnya; echo "] "; ?><b><span style="color:orange;">
	    
	<div class="tooltip"><?php echo $data['nama']; ?><span class="tooltiptext">Mitra yourdomainname.com</span></div>    
	
	</span></b><?php echo " : ";?><span class="chat_user1"><?php echo $data['isi']; ?></span>
	</div>
	<?php
	}
		
		
		
	else if($data['status'] == "pro"){
	?>
	<div  style="margin-left:10px;"><?php echo "["; echo $jamnya; echo "]  "; ?><b><span style="color:black;">
	    
	<div class="tooltip"><?php echo $data['nama']; ?><span class="tooltiptext">Programmer Raiblokc.co.id</span></div>    
	
	</span></b><?php echo " : ";?><span class="chat_user1"><?php echo $data['isi']; ?></span>
	</div>
	<?php
	}
	
	else{
	?>
	<div  style="margin-left:10px;"><?php echo "["; echo $jamnya; echo "] "; ?><b><span style="color:black;"><?php echo $data['nama']; ?></span></b><?php echo " : ";?><span class="chat_user1"><?php echo $data['isi']; ?></span>
	</div>
	
	<?php
		}
    ?>
			

<?php
}


$conn->connClose();

?>
