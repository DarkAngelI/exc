<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$passwordawal = md5($_POST['passwordawal']);
$password1 = md5($_POST['password1']);
$password2 = md5($_POST['password2']);

$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]' and password = '$passwordawal'");
$data = mysql_fetch_array($query);
$num = mysql_num_rows($query);


if($num == 1){	

if($password1 == $password2){

$update = mysql_query("update users set password = '$password2' where iduser = '$_SESSION[iduser]'");

	header('location:profil?pengaturan=5');
}else{
	
	header('location:profil?pengaturan=3');

}
}else{
	header('location:profil?pengaturan=2');
break;
}


		
	
?>