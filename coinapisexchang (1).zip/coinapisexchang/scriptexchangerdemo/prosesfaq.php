<?php

session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();



	
	if($_SESSION['iduser'] == NULL or $_SESSION['level'] == 'admin' ){
		 header("location:masuk.php");
	}else{
		
		$tanya = $_POST['pertanyaan'];
		$jawab = $_POST['jawaban'];
		
		$input = mysql_query("INSERT INTO `faq` (`id`, `iduser`, `pertanyaan`, `jawaban`, `tanggaljam`) VALUES (NULL, '$_SESSION[iduser]', '$tanya', '$jawab', CURRENT_TIMESTAMP);");
		
		header('location:addfaq?sukses=1');
	}
	


?>