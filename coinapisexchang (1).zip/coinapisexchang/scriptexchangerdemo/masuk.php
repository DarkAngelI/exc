<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="icon" type="image/png" href="img/logo-mini.png">
	<title>judul situs</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

<link rel="stylesheet" href="css/lib/lobipanel/lobipanel.min.css">
<link rel="stylesheet" href="css/separate/vendor/lobipanel.min.css">
<link rel="stylesheet" href="css/lib/jqueryui/jquery-ui.min.css">
<link rel="stylesheet" href="css/separate/pages/widgets.min.css">

    <link rel="stylesheet" href="css/lib/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="css/lib/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
	
</head>

<body class="horizontal-navigation">

	<?php
	
//kluarin dl sebelum login




session_start();

// Unset all of the session variables.
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie.
// Note: This will destroy the session, and not just the session data!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finally, destroy the session.
session_destroy();

	
//kluarin dl sebelum login END



		include "header.php";
		
		if($_SESSION['iduser'] != NULL){
			header("location:profil.php");
		}
	?>

	<div class="page-content" style="margin-top:-5%">
	<div class="row">
		<div class="col-lg-2">
		</div>
		<div class="col-lg-8">
	    <div class="container-fluid">
			<section class="card">
				<header class="card-header">
					MASUK
					<button type="button" class="modal-close">
						<i class="fa fa-lock"></i>
					</button>
				</header>
				<div class="card-block">
					<?php
						if(!empty($_GET['sukses']) and $_GET['sukses'] == '1'){
					?>
					<div class="alert alert-success alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
							<strong>OK!</strong> Silahkan Login Untuk Melanjutkan
						</div>
					<?php
						}
					?>
					
					<?php
						if(!empty($_GET['gagal']) and $_GET['gagal'] == 'blokir'){
					?>
					
						<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						<strong>UPPPS!</strong> Akun anda belum aktif atau telah di nonaktifkan oleh admin
						</div> 
					
					
						
						<?php
						}
						
						else if(!empty($_GET['gagal']) and $_GET['gagal'] == '2'){
					?>
					<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
							<strong>UPPPS!</strong> Karakter Mengandung Simbol Yang Dilarang
						</div>
					<?php
						}
						
						else if(!empty($_GET['gagal']) and $_GET['gagal'] == '1'){
					?>
					<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						
							<strong>UPPPS!</strong> Email Atau Password Anda Salah	</div>
					<?php
						}
						
							else if(!empty($_GET['gagal']) and $_GET['gagal'] == '4'){
					?>
					<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						
							<strong>UPPPS!</strong> Anda Telah di keluarkan, Silahkan Login Kembali</div>
					<?php
						}
						
						else if(!empty($_GET['gagal']) and $_GET['gagal'] == '101'){
					?>
					<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
							<strong>UPPPS!</strong> Anda Belum Mengisikan Captcha
						</div>
					<?php
						}else if(!empty($_GET['gagal']) and $_GET['gagal'] == '10'){
					?>
					<div class="alert alert-danger alert-fill alert-border-left alert-close alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
							<strong>UPPPS!</strong> Anda Harus Login Terlebih Dahulu
						</div>
					<?php
						}
					?>
				
						<form action="ceklogin" method="post">
					<div class="form-group row">
						<label class="col-sm-2 form-control-label">Email</label>
						<div class="col-sm-10">
							<p class="form-control-static"><input type="email" class="form-control" placeholder="Email" name="email"></p>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 form-control-label">Password</label>
						<div class="col-sm-10">
							<p class="form-control-static"><input id="hide-show-password" type="password" class="form-control" name="password" placeholder="******"></p>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 form-control-label"></label>
						<div class="col-sm-10">
							<button type="submit" class="btn btn-inline">MASUK</button>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 form-control-label"></label>
						<div class="col-sm-10">
							Atau Belum Punya Akun? <a href="daftar"><button type="button" class="btn btn-rounded btn-inline btn-warning-outline">Daftar Disini</button></a>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 form-control-label"></label>
						<div class="col-sm-10">
							Lupa password Anda? <a href="lupa"><button type="button" class="btn btn-rounded btn-inline btn-danger-outline">Lupa Password</button></a>
						</div>
					</div>
					</form>
				</div>
			</section>
		</div><!--.container-fluid-->
		</div>
		</div>
	</div><!--.page-content-->

	<script src="js/lib/jquery/jquery.min.js"></script>
	<script src="js/lib/tether/tether.min.js"></script>
	<script src="js/lib/bootstrap/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>

	<script type="text/javascript" src="js/lib/jqueryui/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/lib/lobipanel/lobipanel.min.js"></script>
	<script type="text/javascript" src="js/lib/match-height/jquery.matchHeight.min.js"></script>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	
	<script src="js/lib/hide-show-password/bootstrap-show-password.min.js"></script>
	<script src="js/lib/hide-show-password/bootstrap-show-password-init.js"></script>
	


<script src="js/app.js"></script>
</body>
</html>