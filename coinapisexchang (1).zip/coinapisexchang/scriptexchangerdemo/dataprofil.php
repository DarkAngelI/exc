<?php

/*
session_start();
error_reporting(0);


include('koneksi.php');
$conn = new Connection();
$conn->connOpen();
*/

if($_SESSION['iduser'] == NULL){
	 header("location:masuk.php");
}


$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
$data = mysql_fetch_array($query);
?>
					<div class="profile-statistic tbl">
						<div class="tbl-row">
							<hr>
							<img src="./img/bitcoin.png" width="25" height="25" title="bitcoin"> <br><?php echo $data['saldobitcoin']; ?> <br>
							<br>
							<img src="./img/dogecoin.png" width="25" height="25" title="dogecoin"><br><?php echo $data['saldodogecoin']; ?><br>
							<br>
							<img src="./img/litecoin.png" width="25" height="25" title="litecoin"> <br><?php echo $data['saldolitecoin']; ?><br>
							<br>
							<img src="./img/tellecoin.png" width="25" height="25" title="tellecoin"><br><?php echo $data['saldotellecoin']; ?><br>
							<br>
							<img src="./img/litkoin.png" width="55" height="25" title="litkoin"><br><?php echo $data['saldolitkoin']; ?><br>
							<hr>
						</div>
					</div>
					
									
								
					<?php
						$cekclaim = mysql_query("select * from depth where alamatdompet = '$data[alamatdompet]'");
						$cc = mysql_fetch_array($cekclaim);
					?>
					
					
					
					
					
					
					
					
					