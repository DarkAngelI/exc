<?php
session_start();
error_reporting(0);

include('../koneksi.php');
$conn = new Connection();
$conn->connOpen();
?>
<!-- Styles -->
<style>
#chartdiv {
	width		: 100%;
	height		: 500px;
	font-size	: 11px;
}														
</style>

<!-- Resources -->
<script src="amcharts.js"></script>
<script src="serial.js"></script>
<script src="export.min.js"></script>
<link rel="stylesheet" href="export.css" type="text/css" media="all" />
<script src="light.js"></script>
<!-- Chart code -->
<!-- Chart code -->
<script>
var chart = AmCharts.makeChart( "chartdiv", {
  "type": "serial",
  "theme": "light",
  "dataDateFormat":"YYYY-MM-DD",
  "valueAxes": [ {
    "position": "left"
  } ],
  "graphs": [ {
    "id": "g1",
    "balloonText": "Open:<b>[[open]]</b><br>Low:<b>[[low]]</b><br>High:<b>[[high]]</b><br>Close:<b>[[close]]</b><br>",
    "closeField": "close",
    "fillColors": "#46c35f",
    "highField": "high",
    "lineColor": "#46c35f",
    "lineAlpha": 1,
    "lowField": "low",
    "fillAlphas": 0.9,
    "negativeFillColors": "#fa424a",
    "negativeLineColor": "#fa424a",
    "openField": "open",
    "title": "Price:",
    "type": "candlestick",
    "valueField": "close"
  } ],
  "chartScrollbar": {
    "graph": "g1",
    "graphType": "line",
    "scrollbarHeight": 30
  },
  "chartCursor": {
    "valueLineEnabled": true,
    "valueLineBalloonEnabled": true
  },
  "categoryField": "date",
  "categoryAxis": {
    "parseDates": true
  },
  "dataProvider": [ 
  
  <?php
	$query = mysql_query("select * from transaksi_tele_bitcoin_done");
	while($data = mysql_fetch_array($query)){
		$tanggal = substr($data['tanggaljam'],0,10);
		$open = mysql_query("select * from transaksi_tele_bitcoin_done where tanggaljam like '%$tanggal%' and jenis = 'JUAL' order by id asc");
		$op = mysql_fetch_array($open);
		
		$high = mysql_query("select * from transaksi_tele_bitcoin_done where tanggaljam like '%$tanggal%' and jenis = 'JUAL' order by btc desc");
		$hg = mysql_fetch_array($high);
		
		$low = mysql_query("select * from transaksi_tele_bitcoin_done where tanggaljam like '%$tanggal%' and jenis = 'JUAL' order by btc asc");
		$lo = mysql_fetch_array($low);
		
		$close = mysql_query("select * from transaksi_tele_bitcoin_done where tanggaljam like '%$tanggal%' and jenis = 'JUAL' order by id desc");
		$cl = mysql_fetch_array($close);
		
  ?>
  {
    "date": <?php echo '"'.substr($data['tanggaljam'],0,10).'"'; ?>,
    "open": <?php echo '"'.$op['btc'].'"'; ?>,
    "high": <?php echo '"'.$hg['btc'].'"'; ?>,
    "low": <?php echo '"'.$lo['btc'].'"'; ?>,
    "close": <?php echo '"'.$cl['btc'].'"'; ?>
  },
<?php
	}
	?>
  ],
   "export": {
    "enabled": true,
    "position": "bottom-right"
  }
} );

chart.addListener( "rendered", zoomChart );
zoomChart();

// this method is called when chart is first inited as we listen for "dataUpdated" event
function zoomChart() {
  // different zoom methods can be used - zoomToIndexes, zoomToDates, zoomToCategoryValues
  chart.zoomToIndexes( chart.dataProvider.length - 10, chart.dataProvider.length - 1 );
}
</script>

<!-- HTML -->
<div id="chartdiv"></div>		