<!DOCTYPE html><html><head lang="en"><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"><meta http-equiv="x-ua-compatible" content="ie=edge"><link rel="icon" type="image/png" href="img/logo-mini.png"><title>judul situs</title><link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144"><link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114"><link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72"><link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png"><link href="img/favicon.png" rel="icon" type="image/png"><link href="img/favicon.ico" rel="shortcut icon"><link rel="stylesheet" href="css/separate/vendor/slick.min.css"><link rel="stylesheet" href="css/separate/pages/profile.min.css"><link rel="stylesheet" href="css/lib/font-awesome/font-awesome.min.css"><link rel="stylesheet" href="css/lib/bootstrap/bootstrap.min.css"><link rel="stylesheet" href="css/main.css"><link rel="stylesheet" href="css/separate/vendor/jquery-steps.min.css"><link rel="stylesheet" href="css/lib/bootstrap-sweetalert/sweetalert.css"><link rel="stylesheet" href="css/separate/vendor/sweet-alert-animations.min.css"></head><body><?php	include "header.php";	if($_SESSION['iduser'] == NULL){		header("location:masuk.php?gagal=10");	}?>
<div class="page-content">	<div class="container-fluid">		<div class="row">			<div class="col-lg-12 col-lg-pull-6 col-md-6 col-sm-6">				<?php					if(!empty($_GET['gagal']) and $_GET['gagal'] == '5'){				?>				<div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">						UPPPS! Password yang anda isikan salah				</div>				<?php					} else	if(!empty($_GET['gagal']) and $_GET['gagal'] == '2'){				?>				<div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">						UPPPS! request withdraw anda gagal.				</div>
				<?php					} else if(!empty($_GET['gagal']) and $_GET['gagal'] == '6'){				?>
					
				<div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">						UPPPS! Saldo bitcoin anda tidak mencukupi				</div>
				<?php					}else if(!empty($_GET['gagal']) and $_GET['gagal'] == '7'){				?>
				<div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">					UPPPS! Form masih ada yang kosong, pastikan semua form terisi dengan benar				</div>				<?php					}else if(!empty($_GET['gagal']) and $_GET['gagal'] == '8'){				?>				<div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">					UPPPS! Minimum estimasi rupiah yang bisa dicairkan adalah Rp 50.000				</div>
				<?php					}				if(!empty($_GET['sukses']) and $_GET['sukses'] == '5'){				?>
				<div class="alert alert-success alert-fill alert-close alert-dismissible fade in" role="alert">					OK! Pencairan berhasil kami proses, tunggu sekitar tiga hari sampai dana masuk ke rekening anda				</div>				<?php				}					if(!empty($_GET['sukses']) and $_GET['sukses'] == '2'){				?>				<div class="alert alert-success alert-fill alert-close alert-dismissible fade in" role="alert">					OK! request withdraw sudah kami terima, Tunggu beberapa menit				</div>
				<?php				}				?>
			<section class="tabs-section">
			<div class="tabs-section-nav tabs-section-nav-icons">
				<div class="tbl">
					<ul class="nav" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" href="#tabs-1-tab-1" role="tab" data-toggle="tab" aria-expanded="true">
								<span class="nav-link-in">
									<i class="glyphicon glyphicon-piggy-bank"></i>
									DEPOSIT
								</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#tabs-1-tab-2" role="tab" data-toggle="tab" aria-expanded="false">
								<span class="nav-link-in">
									<span class="glyphicon glyphicon-send"></span>
									WITHDRAW
								</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#tabs-1-tab-4" role="tab" data-toggle="tab" aria-expanded="false">
								<span class="nav-link-in">
									<span class="font-icon font-icon-list-rotate"></span>
									RIWAYAT
								</span>
							</a>
						</li>
						
					</ul>
				</div>
			</div><!--.tabs-section-nav-->
			<?php
			
				$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");
				$data =mysql_fetch_array($query);
				
			?>
			
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane fade active in" id="tabs-1-tab-1" aria-expanded="true">
				<div class="row">
		
		
		
		<div class="col-lg-4">
				<section class="card">
				<div class="card-block">
						<div class="form-group">
						<label for="exampleInputEmail1"><b>Deposit Bitcoin</b></label>
						<input type="text" class="form-control" value="<?php echo $data['alamatbitcoin']; ?>" id="copybitcoin" readonly>
						<button class="btn btn-primary swal-btn-custom-bitcoin"><i class="glyphicon glyphicon-qrcode"></i> SCAN</button>
						<button type="button" class="btn btn-inline btn-primary-outline"  onclick="copywallet('#copybitcoin')" style="margin-top:10px;" title="Klik untuk salin alamat BTC">Copy</button>						
						</div>				</div>
				</section>
		</div>
		
		<div class="col-lg-4">
		<section class="card">
			<div class="card-block">
			<div class="form-group">
								<label for="exampleInputEmail1"><b>Deposit Dogecoin</b></label>
								<input type="text" class="form-control" value="<?php echo $data['alamatdogecoin']; ?>" id="copydogecoin" readonly>
							
								<button class="btn btn-primary swal-btn-custom-dogecoin"><i class="glyphicon glyphicon-qrcode"></i> SCAN</button>
								<button type="button" class="btn btn-inline btn-primary-outline" onclick="copywallet('#copydogecoin')" style="margin-top:10px;" title="Klik untuk salin alamat BTC">Copy</button>
				
						</div>
			</div>
		</section>
		</div>
		
		<div class="col-lg-4">
		<section class="card">
			<div class="card-block">
			<div class="form-group">
								<label for="exampleInputEmail1"><b>Deposit Litecoin</b></label>
								<input type="text" class="form-control" value="<?php echo $data['alamatlitecoin']; ?>" id="copylitecoin" readonly>
							
							
								<button class="btn btn-primary swal-btn-custom-litecoin"><i class="glyphicon glyphicon-qrcode"></i> SCAN</button>
								<button type="button" class="btn btn-inline btn-primary-outline" onclick="copywallet('#copylitecoin')" style="margin-top:10px;" title="Klik untuk salin alamat BTC">Copy</button>
						</div>
			</div>
		</section>
		</div>
		
		<div class="col-lg-4">
		<section class="card">
			<div class="card-block">
			<div class="form-group">
								<label for="exampleInputEmail1"><b>Deposit Tellecoin</b></label>
								<input type="text" class="form-control" value="<?php echo $data['alamattellecoin']; ?>" id="copytellecoin" readonly>
								
								<button class="btn btn-primary swal-btn-custom-tellecoin"><i class="glyphicon glyphicon-qrcode"></i> SCAN</button>
								<button type="button" class="btn btn-inline btn-primary-outline" onclick="copywallet('#copytellecoin')" style="margin-top:10px;" title="Klik untuk salin alamat BTC">Copy</button>
						</div>
			</div>
		</section>
		</div>
		
		<div class="col-lg-4">
		<section class="card">
			<div class="card-block">
			<div class="form-group">
								<label for="exampleInputEmail1"><b>Deposit LitKoin</b></label>
								<input type="text" class="form-control" value="<?php echo $data['alamatlitkoin']; ?>" id="copylitkoin" readonly>
								
								<button class="btn btn-primary swal-btn-custom-litkoin"><i class="glyphicon glyphicon-qrcode"></i> SCAN</button>
								<button type="button" class="btn btn-inline btn-primary-outline" onclick="copywallet('#copylitkoin')" style="margin-top:10px;" title="Klik untuk salin alamat BTC">Copy</button>
						</div>
			</div>
		</section>
		</div>
		
		
		</div>
		
				</div><!--.tab-pane-->
				<div role="tabpanel" class="tab-pane fade" id="tabs-1-tab-2" aria-expanded="false">
				
				
				<div class="row">
						
						
						
						
						
						<div class="col-lg-12">
						<section class="card">
						<div class="card-block">
						<h4>KIRIM BITCOIN</h4>
						<script src="jquery.min.js"></script>
							<script>
							$(document).ready(function() {
							$("#saldobitcoin").load("saldobitcoin.php");
							var refreshId = setInterval(function() 
							{
							$("#saldobitcoin").load('saldobitcoin.php?randval='+ Math.random());
							}, 1000);
							});
							</script>
						<form action="kirimbitcoin.php" method="post">
						<!--<form action="#" method="post">-->
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Saldo BITCOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><div id="saldobitcoin"></div></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Jumlah BITCOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" name="bitcoin" class="form-control" value="0.000"></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Biaya</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" value="0.0005 BITCOIN" disabled></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Alamat BITCOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" name="alamat" required></p>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label"></label>
							<div class="col-sm-10">
								<button type="submit" onclick="return confirm('Pastikan alamat bitcoin yang anda isikan benar?')" class="btn btn-inline btn-primary-outline">KIRIM BITCOIN</button>
							</div>
						</div>
						</form>
						*) Minimum kirim Bitcoin adalah 0.001 
						</div>
						</section>
						</div>
						
						
			
						
						<div class="col-lg-12">
						<section class="card">
						<div class="card-block">
						<h4>KIRIM DOGECOIN</h4>
							<script>
							$(document).ready(function() {
							$("#saldodogecoin").load("saldodogecoin.php");
							var refreshId = setInterval(function() 
							{
							$("#saldodogecoin").load('saldodogecoin.php?randval='+ Math.random());
							}, 1000);
							});
							</script>
						<form action="kirimdogecoin.php" method="post">
						<!--<form action="#" method="post">-->
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Saldo Dogecoin</label>
							<div class="col-sm-10">
								<p class="form-control-static"><div id="saldodogecoin"></div></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Jumlah Dogecoin</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" name="dogecoin" class="form-control" value="0.000"></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Biaya</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" value="5 DOGECOIN" disabled></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Alamat Dogecoin</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" name="alamat" required></p>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label"></label>
							<div class="col-sm-10">
								<button type="submit" onclick="return confirm('Pastikan alamat dogecoin yang anda isikan benar?')" class="btn btn-inline btn-primary-outline">KIRIM DOGECOIN</button>
							</div>
						</div>
						</form>
						*) Minimum kirim dogecoin adalah 10 Doge
						</div>
						</section>
						</div>
						
						
			
						
						<div class="col-lg-12">
						<section class="card">
						<div class="card-block">
						<h4>KIRIM LITECOIN</h4>
							<script>
							$(document).ready(function() {
							$("#saldolitecoin").load("saldolitecoin.php");
							var refreshId = setInterval(function() 
							{
							$("#saldolitecoin").load('saldolitecoin.php?randval='+ Math.random());
							}, 1000);
							});
							</script>
						<form action="kirimlitecoin.php" method="post">
						<!--<form action="#" method="post">-->
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Saldo LITECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><div id="saldolitecoin"></div></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Jumlah LITECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" name="litecoin" class="form-control" value="0.000"></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Biaya</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" value="0.0005 LITECOIN" disabled></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Alamat LITECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" name="alamat" required></p>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label"></label>
							<div class="col-sm-10">
								<button type="submit" onclick="return confirm('Pastikan alamat litecoin yang anda isikan benar?')" class="btn btn-inline btn-primary-outline">KIRIM LITECOIN</button>
							</div>
						</div>
						</form>
						*) Minimum kirim Litecoin adalah 0.001 
						</div>
						</section>
						</div>
						
						
			
						
						<div class="col-lg-12">
						<section class="card">
						<div class="card-block">
						<h4>KIRIM TELLECOIN</h4>
							<script>
							$(document).ready(function() {
							$("#saldotellecoin").load("saldotellecoin.php");
							var refreshId = setInterval(function() 
							{
							$("#saldotellecoin").load('saldotellecoin.php?randval='+ Math.random());
							}, 1000);
							});
							</script>
						<form action="kirimtellecoin.php" method="post">
						<!--<form action="#" method="post">-->
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Saldo TELLECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><div id="saldotellecoin"></div></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Jumlah TELLECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" name="tellecoin" class="form-control" value="0.000"></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Biaya</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" value="5 TELLECOIN" disabled></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Alamat TELLECOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" name="alamat" required></p>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label"></label>
							<div class="col-sm-10">
								<button type="submit" onclick="return confirm('Pastikan alamat tellecoin yang anda isikan benar?')" class="btn btn-inline btn-primary-outline">KIRIM TELLECOIN</button>
							</div>
						</div>
						</form>
						*) Minimum kirim tellecoin adalah 10
						</div>
						</section>
						</div>
						
						
			
						<div class="col-lg-12">
						<section class="card">
						<div class="card-block">
						<h4>KIRIM LITKOIN</h4>
							<script>
							$(document).ready(function() {
							$("#saldolitkoin").load("saldolitkoin.php");
							var refreshId = setInterval(function() 
							{
							$("#saldolitkoin").load('saldolitkoin.php?randval='+ Math.random());
							}, 1000);
							});
							</script>
						<form action="kirimlitkoin.php" method="post">
						<!--<form action="#" method="post">-->
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Saldo LITKOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><div id="saldolitkoin"></div></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Jumlah LITKOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" name="litkoin" class="form-control" value="0.000"></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Biaya</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" value="5 LITKOIN" disabled></p>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 form-control-label">Alamat LITKOIN</label>
							<div class="col-sm-10">
								<p class="form-control-static"><input type="text" class="form-control" name="alamat" required></p>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-2 form-control-label"></label>
							<div class="col-sm-10">
								<button type="submit" onclick="return confirm('Pastikan alamat litkoin yang anda isikan benar?')" class="btn btn-inline btn-primary-outline">KIRIM LITKOIN</button>
							</div>
						</div>
						</form>
						*) Minimum kirim litkoin adalah 10 
						</div>
						</section>
						</div>
						
						
			
			
			
			
				</div>
				
				
				
				
				
				
				<i>Perhatian : Pengiriman digital aset membutuhkan konfirmasi admin, WITHDRAW mungkin memerlukan beberapa menit untuk diverifikasi.</i><br>
				</div><!--.tab-pane-->
				<div role="tabpanel" class="tab-pane fade" id="tabs-1-tab-3" aria-expanded="false">
					<div class="row">
				<div class="col-lg-12">
					<section class="box-typical box-panel">
			<div class="box-typical-body">
			
			<script type="text/javascript">
			function toRp(angka){
			var rev     = parseInt(angka, 10).toString().split('').reverse().join('');
			var rev2    = '';
			for(var i = 0; i < rev.length; i++){
				rev2  += rev[i];
				if((i + 1) % 3 === 0 && i !== (rev.length - 1)){
					rev2 += '.';
				}
			}
			return rev2.split('').reverse().join('');
}
									   function startCalcBtc(){
										interval = setInterval("calcBtc()",1);
										}
										function calcBtc(){
											rate = ($('#rate').val()+'').replace(/[^0-9]/g,'');												
											btc = document.getElementById("btc").value;
											rumus = (btc*rate)-15000;
											if(rumus < 0){
											$('#estimasi').val(toRp(0));
											}else{
											$('#estimasi').val(toRp(rumus));
											}
											return;
											}
											function stopCalcBtc(){
												clearInterval(interval);
											}
									</script>
									
				</div><!--.box-typical-body-->
		</section>
				
				</div>
				</div>
				
				</div><!--.tab-pane-->
				
				<div role="tabpanel" class="tab-pane fade" id="tabs-1-tab-4" aria-expanded="false">
				<div style="overflow-x:auto;">
					<table id="table-xs" class="table table-bordered table-hover table-xs">
			<thead>
			<tr>
				<th><center>TANGGAL</center></th>
				<th><center>JENIS</center></th>
				<th><center>MATA UANG</center></th>
				<th><center>NOMINAL</center></th>
			</tr>
			</thead>
			<tbody>
			<?php
				$query = mysql_query("select * from riwayattx where iduser = '$_SESSION[iduser]' order by id desc");
				$nums = mysql_num_rows($query);
				
				if($nums != 0){
				while($data = mysql_fetch_array($query)){
			?>
			<tr>
				<td><center><?php echo $data['tanggaljam']; ?></center></td>
				<td><center><?php echo strtoupper($data['jenis']); ?></center></td>
				<td><center><?php echo strtoupper($data['matauang']); ?></center></td>
				<td><center><?php echo $data['nominal']; ?></center></td>
			</tr>
			<?php
				}
				
				}else{
			?>
			<tr>
				<td colspan="5"><center>Tidak Ada Data</center></td>
			</tr>
			<?php
				}
			?>
			</tbody>
		</table>
		<br>
		<i>Perhatian : Pengiriman digital Aset perlu konfirmasi admin, WITHDRAW mungkin memerlukan beberapa menit untuk diverifikasi</i><br>
		</div>
		
				</div><!--.tab-pane-->
			</div><!--.tab-content-->
		</section>
		
			</div><!--.col- -->
			
		</div><!--.row-->
		
		
	</div><!--.container-fluid-->
</div><!--.page-content-->
	<script src="js/lib/jquery/jquery.min.js"></script>
	<script src="js/lib/tether/tether.min.js"></script>
	<script src="js/lib/bootstrap/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/lib/slick-carousel/slick.min.js"></script>
	
	<script language="Javascript" type="text/Javascript">
<script>
function copywallet(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>
<script>
	$(function () {
		$(".profile-card-slider").slick({
			slidesToShow: 1,
			adaptiveHeight: true,
			prevArrow: '<i class="slick-arrow font-icon-arrow-left"></i>',
			nextArrow: '<i class="slick-arrow font-icon-arrow-right"></i>'
		});
		var postsSlider = $(".posts-slider");
		postsSlider.slick({
			slidesToShow: 3,
			adaptiveHeight: true,
			arrows: false,
			responsive: [
				{
					breakpoint: 1700,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 1350,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 500,
					settings: {
						slidesToShow: 1
					}
				}
			]
		});
		$('.posts-slider-prev').click(function(){
			postsSlider.slick('slickPrev');
		});
		$('.posts-slider-next').click(function(){
			postsSlider.slick('slickNext');
		});
		/* ==========================================================================
		 Recomendations slider
		 ========================================================================== */
		var recomendationsSlider = $(".recomendations-slider");
		recomendationsSlider.slick({
			slidesToShow: 4,
			adaptiveHeight: true,
			arrows: false,
			responsive: [
				{
					breakpoint: 1700,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 1350,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 500,
					settings: {
						slidesToShow: 1
					}
				}
			]
		});
		$('.recomendations-slider-prev').click(function() {
			recomendationsSlider.slick('slickPrev');
		});
		$('.recomendations-slider-next').click(function(){
			recomendationsSlider.slick('slickNext');
		});
	});
</script>
<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/tether/tether.min.js"></script>
<script src="js/lib/bootstrap/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/lib/jquery-validation/jquery.validate.min.js"></script>
<script src="js/lib/jquery-steps/jquery.steps.min.js"></script>
<script>
	$(function() {
		$("#example-basic ").steps({
			headerTag: "h3",
			bodyTag: "section",
			transitionEffect: "slideLeft",
			autoFocus: true
		});
		var form = $("#example-form");
		form.validate({
			rules: {
				agree: {
					required: true
				}
			},
			errorPlacement: function errorPlacement(error, element) { element.closest('.form-group').find('.form-control').after(error); },
			highlight: function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			unhighlight: function(element) {
				$(element).closest('.form-group').removeClass('has-error');
			}
		});
		form.children("div").steps({
			headerTag: "h3",
			bodyTag: "section",
			transitionEffect: "slideLeft",
			onStepChanging: function (event, currentIndex, newIndex)
			{
				form.validate().settings.ignore = ":disabled,:hidden";
				return form.valid();
			},
			onFinishing: function (event, currentIndex)
			{
				document.forms["example-form"].submit();
				return form.valid();
			}
		});
		$("#example-tabs").steps({
			headerTag: "h3",
			bodyTag: "section",
			transitionEffect: "slideLeft",
			enableFinishButton: false,
			enablePagination: false,
			enableAllSteps: true,
			titleTemplate: "#title#",
			cssClass: "tabcontrol"
		});
		$("#example-vertical").steps({
			headerTag: "h3",
			bodyTag: "section",
			transitionEffect: "slideLeft",
			stepsOrientation: "vertical"
		});
	});
</script>
<script src="js/lib/tether/tether.min.js"></script>
<script src="js/lib/bootstrap/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/lib/bootstrap-sweetalert/sweetalert.min.js"></script>
<script>
	$(document).ready(function() {
		$('.swal-btn-custom-bitcoin').click(function(e){
			e.preventDefault();
			swal({
				title: "Bitcoin QR Code",
				text: "",
				confirmButtonClass: "btn-success",
				imageUrl: 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=<?php echo $data['alamatbitcoin']; ?>&choe=UTF-8'
			});
		});
		
	});
	
	$(document).ready(function() {
		$('.swal-btn-custom-dogecoin').click(function(e){
			e.preventDefault();
			swal({
				title: "DogeCoin QR Code",
				text: "",
				confirmButtonClass: "btn-success",
				imageUrl: 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=<?php echo $data['alamatdogecoin']; ?>&choe=UTF-8'
			});
		});
		
	});
	
	$(document).ready(function() {
		$('.swal-btn-custom-litecoin').click(function(e){
			e.preventDefault();
			swal({
				title: "LiteCoin QR Code",
				text: "",
				confirmButtonClass: "btn-success",
				imageUrl: 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=<?php echo $data['alamatlitecoin']; ?>&choe=UTF-8'
			});
		});
		
	});
	
	$(document).ready(function() {
		$('.swal-btn-custom-tellecoin').click(function(e){
			e.preventDefault();
			swal({
				title: "Tellecoin QR Code",
				text: "",
				confirmButtonClass: "btn-success",
				imageUrl: 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=<?php echo $data['alamattellecoin']; ?>&choe=UTF-8'
			});
		});
		
	});
	
	$(document).ready(function() {
		$('.swal-btn-custom-litkoin').click(function(e){
			e.preventDefault();
			swal({
				title: "LitKoin QR Code",
				text: "",
				confirmButtonClass: "btn-success",
				imageUrl: 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=<?php echo $data['alamatlitkoin']; ?>&choe=UTF-8'
			});
		});
		
	});
</script>
<script src="js/app.js"></script>
</body>
</html>