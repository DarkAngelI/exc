<?php

session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();



	
	if($_SESSION['iduser'] == NULL or $_SESSION['level'] == 'admin' ){
		 header("location:masuk.php");
	}else{
		
		$id = $_GET['id'];
		
		$delete = mysql_query("delete from faq where id = '$_GET[id]'");
		
		header('location:addfaq?sukses=1');
	}
	


?>