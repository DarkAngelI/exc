<?php
session_start();
error_reporting(0);

include('koneksi.php');
$conn = new Connection();
$conn->connOpen();

$email = $_POST['email'];
$nohp = $_POST['nohp'];

if (preg_match("/^[a-zA-Z0-9.@]*$/",$email)) { 


if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
if(!$captcha){
          header('location:lupa?gagal=101');
		  break;
        }
		
		

		

		
		
		$secretKey = "6LebJRcUAAAAAKoPROh1mxHCu1nzB4PJJw84Cw0j";
        $ip = $_SERVER['REMOTE_ADDR'];
        $response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip);
        $responseKeys = json_decode($response,true);
      
	

	  if(intval($responseKeys["success"]) !== 1) {
           header('location:lupa?gagal=101');
        } else {

$query = mysql_query("select * from users where email = '$email' and nohp = '$nohp'");
$data = mysql_fetch_array($query);
$num = mysql_num_rows($query);

if($num == 1){
$pass = rand(111111111,999999999);
$newpass = md5($pass);
$nama = $data['nama'];

$update = mysql_query("update users set password = '$newpass' where email = '$email' and nohp = '$nohp'");

//ngemail
	require_once('email/function.php');
	    
    $to       = $email;
    $subject  = 'Reset Password yourdomainname.com';
	$message = "Password : $pass <br>";
	
    smtp_mail($to, $subject, $message, '', '', 0, 0, true);   
//ngemail stop	
	
	
	header('location:lupa.php?sukses=1');
}else{
	
	header('location:lupa.php?gagal=1');
}

}

}else{
	header('location:lupa.php?gagal=2');
	
}

	
?>