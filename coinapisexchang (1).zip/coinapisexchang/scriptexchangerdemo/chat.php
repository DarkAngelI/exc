



<!DOCTYPE html>

<!-- saved from url=(0031)https://raiblockscommunity.net/ -->

<html lang="en">



		

		<title>judul situs</title>

		<link rel="icon" type="image/png" href="https://raiblockscommunity.net/media/logo-mini.png?v=1.5.1">

		<link href="bekerja_files/css" rel="stylesheet">

		<link href="bekerja_files/main.css" rel="stylesheet" type="text/css">

		<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

		

<body>



	<?php

	

	include "header.php";

	require('chatconfig.php');

	?>

	

	<?php

		if($_SESSION['iduser'] == NULL){

			

			header('location:masuk.php');

			

		}

	?>

	

	<div class="page">

	

	<center><img style="height:80px;margin:10px 10px -25px 20px" src="bekerja_files/logo.png"></center>

	

		<!-- <p style="text-align: center; font-size: 1.5rem;">

			<font style="color: #bbd631;">Fast</font> &nbsp; 

			<font style="color: #49b749;">Free</font> &nbsp; 

			<font style="color: #40b299;">Scalable</font> &nbsp; 

			<font style="color: #1993d2;">Unlimited</font>

		</p> -->



			<br/><br/><br/>

			<hr>

		<br/>

		

			

<script language="Javascript" type="text/Javascript" src="jquery.min.js"></script>

<script language="Javascript" type="text/Javascript">

<!--

var chat_username = "";

var chat_refresh = 0;

var last_update = 0;

var last_post = 0;

var post_delay = <?php echo $chat_timelimit; ?>;

var post_delay_comment = 0;





function chat_delay_update() {

	tmp = (new Date().getTime()/1000);

	if((last_post+post_delay)<tmp) {

		$("#id_chat_delay").css("display","none");

		$("#id_chat_send").removeAttr('disabled');

		clearInterval(post_delay_comment);

		return;

	}

	

	$("#id_chat_delay").html("Anda bisa mengirim lagi setelah "+Math.round((last_post+post_delay)-tmp)+" detik...");

}



function chat_update() {

	last_update = new Date().getTime();

	

	$.get("chatview.php", { lastfetch : last_update }, function(data) {

		$("#chat_text").html(data);

		$("#chat_text").scrollTop($("#chat_text").height()+$("#chat_text").scrollTop());

	});

}



function post_message() {

	if((last_post+post_delay)>=(new Date().getTime()/1000)) { return; }

	

	var chat_message = $("#id_chat_message").val();

	if(chat_message.length) {

		$.post("chatsend.php",{ username : chat_username, message : chat_message });

		$("#id_chat_message").val("");

	}

	

	$("#id_chat_send").attr('disabled','disabled');

	last_post = (new Date().getTime()/1000);

	post_delay_comment = window.setInterval('chat_delay_update();', 1000);

	chat_delay_update();

	$("#id_chat_delay").css("display","block");

}



$(function() {

	$("#chat_container").css("display","block");

	

	$("#id_chat_set_username").click(function() {

		var tmp = $("#id_chat_username").val();

		

		if(tmp.match(/^[a-z0-9_\-\s]{3,30}$/i)==null) {

			$("#id_chat_username").addClass("chat_bad_username");



		}else{

			$("#chat_form_username").css("display","none");

			$("#chat_form_message").css("display","block");

			chat_username = tmp;

			

			chat_refresh = window.setInterval('chat_update();', <?php echo $chat_refresh*1000; ?>);

			

			$("#id_chat_send").click(function() {

				post_message();

			});

			$("#id_chat_message").keypress(function(event) {

				if(event.which==13) {

					post_message();

				}

			});

		}

	});

});





$(document).ready(function(){

  $('#id_chat_set_username').trigger('click');

});

// -->

</script>



<style type="text/css">

body {

	font-size:0.7em;

	font-family:Helvetica, Arial, sans-serif;

	color:#777777;

}

#chat_container {

	display:none;

	padding:5px;

	border:2px solid #DDDDDD;

	border-radius:8px;

	width:420px;

	text-align:left;

}

.chat_bad_username {

	border:3px solid #C00;

	

}	



.chat_user{

	font-weight:bold;

	color:black;

	padding-right:8px;

}



.chat_user1 {

	font-weight:bold;

	color:red;

	padding-right:8px;

}



.chat_user2 {

	font-weight:bold;

	color:blue;

	padding-right:8px;

}



#chat_text {

	width:100%;

	height:150px;

	border:1px solid #ccc;

	text-align:left;

	overflow:auto;

}

#chat_form_message {

	display:none;

}

#id_chat_message {

	width:1200px;

}

#id_chat_send {

	width:100px;

}







#chat_noscript div {

	padding:10px;

	width:400px;

	border:2px solid #CC0000;

	background-color:#FFFFDD;

}

#id_chat_delay {

	display:none;

	font-weight:bold;

	color:#999999;

}

</style>

</head>



<body>



<noscript id="chat_noscript">

<div>Silahkan Menggunakan Brwoser lain yang mendukung Java script</div>

</noscript>

<center>



	<input type="hidden" value="<?php echo $_SESSION['iduser']; ?>" name="iduser" id="iduser">

	<div id="chat_text" style="width:1200px;height:300px;font-size:12pt">Silahkan masukan nama anda terlebih dahulu</div>

	<div id="chat_form">

		<div id="chat_form_username">

			<?php

				$query = mysql_query("select * from users where iduser = '$_SESSION[iduser]'");

				$data = mysql_fetch_array($query);

				$nama = strtolower(substr($data['nama'],0,30));

			?>

			<input type="text" id="id_chat_username"  placeholder="Masukan Nama Anda!" value="<?php echo $nama; ?>" disabled>

			<input type="button" value="Mulai Chat" id="id_chat_set_username">



		</div>

<form action="chatsend.php">
		<div id="chat_form_message">

			<input type="text" name="isi" class="form-control" id="id_chat_message" placeholder="Tekan enter untuk kirim" maxlength="<?php echo $chat_maxline; ?>">

			<input type="button" id="id_chat_send" value="Send">

			</form>

			<div id="id_chat_delay">

				Please wait before posting again...

			</div>

		</div>

	</div>



</center>

	

	</div>



	<!-- 			

	<script type="text/javascript"  charset="utf-8">

	// Place this code snippet near the footer of your page before the close of the /body tag

	// LEGAL NOTICE: The content of this website and all associated program code are protected under the Digital Millennium Copyright Act. Intentionally circumventing this code may constitute a violation of the DMCA.

	                            

	eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(';q P=\'\',28=\'21\';1P(q i=0;i<12;i++)P+=28.11(D.L(D.O()*28.H));q 2y=1,2m=36,2d=4y,34=4z,2B=F(t){q i=!1,o=F(){z(k.1h){k.3c(\'2Z\',e);G.3c(\'1T\',e)}S{k.2W(\'2N\',e);G.2W(\'26\',e)}},e=F(){z(!i&&(k.1h||4A.2G===\'1T\'||k.2T===\'2Q\')){i=!0;o();t()}};z(k.2T===\'2Q\'){t()}S z(k.1h){k.1h(\'2Z\',e);G.1h(\'1T\',e)}S{k.2O(\'2N\',e);G.2O(\'26\',e);q n=!1;2L{n=G.4C==4D&&k.1X}2X(r){};z(n&&n.2U){(F a(){z(i)J;2L{n.2U(\'14\')}2X(e){J 4E(a,50)};i=!0;o();t()})()}}};G[\'\'+P+\'\']=(F(){q t={t$:\'21+/=\',4x:F(e){q a=\'\',d,n,i,c,s,l,o,r=0;e=t.e$(e);1f(r<e.H){d=e.17(r++);n=e.17(r++);i=e.17(r++);c=d>>2;s=(d&3)<<4|n>>4;l=(n&15)<<2|i>>6;o=i&63;z(37(n)){l=o=64}S z(37(i)){o=64};a=a+X.t$.11(c)+X.t$.11(s)+X.t$.11(l)+X.t$.11(o)};J a},13:F(e){q n=\'\',d,l,c,s,r,o,a,i=0;e=e.1r(/[^A-4F-4H-9\\+\\/\\=]/g,\'\');1f(i<e.H){s=X.t$.1M(e.11(i++));r=X.t$.1M(e.11(i++));o=X.t$.1M(e.11(i++));a=X.t$.1M(e.11(i++));d=s<<2|r>>4;l=(r&15)<<4|o>>2;c=(o&3)<<6|a;n=n+T.U(d);z(o!=64){n=n+T.U(l)};z(a!=64){n=n+T.U(c)}};n=t.n$(n);J n},e$:F(t){t=t.1r(/;/g,\';\');q n=\'\';1P(q i=0;i<t.H;i++){q e=t.17(i);z(e<1A){n+=T.U(e)}S z(e>36&&e<4I){n+=T.U(e>>6|4J);n+=T.U(e&63|1A)}S{n+=T.U(e>>12|2C);n+=T.U(e>>6&63|1A);n+=T.U(e&63|1A)}};J n},n$:F(t){q i=\'\',e=0,n=4K=1n=0;1f(e<t.H){n=t.17(e);z(n<1A){i+=T.U(n);e++}S z(n>4L&&n<2C){1n=t.17(e+1);i+=T.U((n&31)<<6|1n&63);e+=2}S{1n=t.17(e+1);2p=t.17(e+2);i+=T.U((n&15)<<12|(1n&63)<<6|2p&63);e+=3}};J i}};q a=[\'4M==\',\'4N\',\'4O=\',\'4G\',\'4v\',\'4l=\',\'4u=\',\'4d=\',\'4e\',\'4f\',\'4g=\',\'4h=\',\'4i\',\'4j\',\'4c=\',\'4k\',\'4m=\',\'4n=\',\'4o=\',\'4p=\',\'4q=\',\'4r=\',\'4s==\',\'4t==\',\'4P==\',\'4w==\',\'4Q=\',\'5d\',\'5f\',\'5g\',\'5h\',\'5i\',\'5j\',\'5k==\',\'5l=\',\'5m=\',\'5e=\',\'5n==\',\'5p=\',\'5q\',\'5r=\',\'5s=\',\'5t==\',\'5u=\',\'5v==\',\'5w==\',\'5o=\',\'5c=\',\'52\',\'5x==\',\'5b==\',\'4T\',\'4U==\',\'4V=\'],g=D.L(D.O()*a.H),Y=t.13(a[g]),w=Y,C=1,W=\'#4W\',r=\'#4X\',b=\'#4Y\',v=\'#4Z\',A=\'\',y=\'4S!\',f=\'51 53 54 55\\\'56 57 58 2n 2g. 59\\\'s 5a.  4R 4b\\\'t?\',u=\'47 49 3g-3f, 3d 3l\\\'t 3r 3s X 3t 3x 3y.\',s=\'I 3j, I 3z 3v 3u 2n 2g.  3q 3p 3o!\',i=0,p=0,n=\'3n.3m\',l=0,Q=e()+\'.3a\';F h(t){z(t)t=t.1L(t.H-15);q i=k.2E(\'3k\');1P(q n=i.H;n--;){q e=T(i[n].1I);z(e)e=e.1L(e.H-15);z(e===t)J!0};J!1};F m(t){z(t)t=t.1L(t.H-15);q e=k.3e;x=0;1f(x<e.H){1m=e[x].1p;z(1m)1m=1m.1L(1m.H-15);z(1m===t)J!0;x++};J!1};F e(t){q n=\'\',i=\'21\';t=t||30;1P(q e=0;e<t;e++)n+=i.11(D.L(D.O()*i.H));J n};F o(i){q o=[\'3h\',\'3w==\',\'3B\',\'3S\',\'2H\',\'3U==\',\'3V=\',\'3W==\',\'3X=\',\'3Y==\',\'3Z==\',\'3T==\',\'41\',\'43\',\'44\',\'2H\'],r=[\'2j=\',\'45==\',\'46==\',\'3A==\',\'48=\',\'42\',\'3R=\',\'3C=\',\'2j=\',\'3Q\',\'3P==\',\'3O\',\'3N==\',\'3M==\',\'3L==\',\'3K=\'];x=0;1R=[];1f(x<i){c=o[D.L(D.O()*o.H)];d=r[D.L(D.O()*r.H)];c=t.13(c);d=t.13(d);q a=D.L(D.O()*2)+1;z(a==1){n=\'//\'+c+\'/\'+d}S{n=\'//\'+c+\'/\'+e(D.L(D.O()*20)+4)+\'.3a\'};1R[x]=23 24();1R[x].1U=F(){q t=1;1f(t<7){t++}};1R[x].1I=n;x++}};F M(t){};J{38:F(t,r){z(3J k.N==\'3I\'){J};q i=\'0.1\',r=w,e=k.1b(\'1x\');e.16=r;e.j.1l=\'1J\';e.j.14=\'-1i\';e.j.10=\'-1i\';e.j.1c=\'29\';e.j.V=\'3H\';q d=k.N.2P,a=D.L(d.H/2);z(a>15){q n=k.1b(\'2b\');n.j.1l=\'1J\';n.j.1c=\'1v\';n.j.V=\'1v\';n.j.10=\'-1i\';n.j.14=\'-1i\';k.N.3G(n,k.N.2P[a]);n.1d(e);q o=k.1b(\'1x\');o.16=\'2M\';o.j.1l=\'1J\';o.j.14=\'-1i\';o.j.10=\'-1i\';k.N.1d(o)}S{e.16=\'2M\';k.N.1d(e)};l=3F(F(){z(e){t((e.1W==0),i);t((e.1Y==0),i);t((e.1S==\'2F\'),i);t((e.1G==\'2q\'),i);t((e.1K==0),i)}S{t(!0,i)}},27)},1O:F(e,c){z((e)&&(i==0)){i=1;G[\'\'+P+\'\'].1C();G[\'\'+P+\'\'].1O=F(){J}}S{q u=t.13(\'3E\'),p=k.3D(u);z((p)&&(i==0)){z((2m%3)==0){q l=\'5z=\';l=t.13(l);z(h(l)){z(p.1Q.1r(/\\s/g,\'\').H==0){i=1;G[\'\'+P+\'\'].1C()}}}};q g=!1;z(i==0){z((2d%3)==0){z(!G[\'\'+P+\'\'].2o){q d=[\'6a==\',\'7w==\',\'7C=\',\'6U=\',\'71=\'],m=d.H,r=d[D.L(D.O()*m)],a=r;1f(r==a){a=d[D.L(D.O()*m)]};r=t.13(r);a=t.13(a);o(D.L(D.O()*2)+1);q n=23 24(),s=23 24();n.1U=F(){o(D.L(D.O()*2)+1);s.1I=a;o(D.L(D.O()*2)+1)};s.1U=F(){i=1;o(D.L(D.O()*3)+1);G[\'\'+P+\'\'].1C()};n.1I=r;z((34%3)==0){n.26=F(){z((n.V<8)&&(n.V>0)){G[\'\'+P+\'\'].1C()}}};o(D.L(D.O()*3)+1);G[\'\'+P+\'\'].2o=!0};G[\'\'+P+\'\'].1O=F(){J}}}}},1C:F(){z(p==1){q Z=2e.7d(\'2f\');z(Z>0){J!0}S{2e.7c(\'2f\',(D.O()+1)*27)}};q h=\'7a==\';h=t.13(h);z(!m(h)){q c=k.1b(\'78\');c.1Z(\'76\',\'74\');c.1Z(\'2G\',\'1g/6T\');c.1Z(\'1p\',h);k.2E(\'73\')[0].1d(c)};72(l);k.N.1Q=\'\';k.N.j.19+=\'R:1v !1a\';k.N.j.19+=\'1u:1v !1a\';q Q=k.1X.1Y||G.39||k.N.1Y,g=G.70||k.N.1W||k.1X.1W,a=k.1b(\'1x\'),C=e();a.16=C;a.j.1l=\'2t\';a.j.14=\'0\';a.j.10=\'0\';a.j.V=Q+\'1z\';a.j.1c=g+\'1z\';a.j.2i=W;a.j.1V=\'6Z\';k.N.1d(a);q d=\'<a 1p="6Y://6X.6W"><2w 16="2x" V="2K" 1c="40"><2A 16="2z" V="2K" 1c="40" 5y:1p="6V:2A/7h;75,7j+7v+7F+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+7A+7H+7E/7B/7G/7D/7k/7y+/7x/7z+7u/7t+7s/7r/7q/7p/7o/7n/7m+7l/77+6S+6f+6Q+5U+5V/5W+5X/5Y+5Z/5T+61+66+67+68/69+6R/6b/6c/62+5R+5I/5Q+5B+5C+5D+E+5E/5F/5G/5A/5H/5J/+5K/5L++5M/5N/5O+5P/6d+5S+6e==">;</2w></a>\';d=d.1r(\'2x\',e());d=d.1r(\'2z\',e());q o=k.1b(\'1x\');o.1Q=d;o.j.1l=\'1J\';o.j.1y=\'1N\';o.j.14=\'1N\';o.j.V=\'6A\';o.j.1c=\'6B\';o.j.1V=\'2l\';o.j.1K=\'.6\';o.j.2k=\'2h\';o.1h(\'6C\',F(){n=n.6D(\'\').6E().6F(\'\');G.2r.1p=\'//\'+n});k.1F(C).1d(o);q i=k.1b(\'1x\'),M=e();i.16=M;i.j.1l=\'2t\';i.j.10=g/7+\'1z\';i.j.6z=Q-6H+\'1z\';i.j.6J=g/3.5+\'1z\';i.j.2i=\'#6K\';i.j.1V=\'2l\';i.j.19+=\'K-1w: "6L 6M", 1o, 1t, 1s-1q !1a\';i.j.19+=\'6N-1c: 6P !1a\';i.j.19+=\'K-1k: 6I !1a\';i.j.19+=\'1g-1D: 1B !1a\';i.j.19+=\'1u: 6x !1a\';i.j.1S+=\'33\';i.j.2Y=\'1N\';i.j.6o=\'1N\';i.j.6w=\'2D\';k.N.1d(i);i.j.6i=\'1v 6k 6l -6m 6g(0,0,0,0.3)\';i.j.1G=\'2u\';q w=30,x=22,Y=18,A=18;z((G.39<3b)||(6n.V<3b)){i.j.2V=\'50%\';i.j.19+=\'K-1k: 6p !1a\';i.j.2Y=\'6q;\';o.j.2V=\'65%\';q w=22,x=18,Y=12,A=12};i.1Q=\'<2R j="1j:#6r;K-1k:\'+w+\'1E;1j:\'+r+\';K-1w:1o, 1t, 1s-1q;K-1H:6s;R-10:1e;R-1y:1e;1g-1D:1B;">\'+y+\'</2R><32 j="K-1k:\'+x+\'1E;K-1H:6t;K-1w:1o, 1t, 1s-1q;1j:\'+r+\';R-10:1e;R-1y:1e;1g-1D:1B;">\'+f+\'</32><6u j=" 1S: 33;R-10: 0.35;R-1y: 0.35;R-14: 2c;R-2v: 2c; 2I:6v 7i #4a; V: 25%;1g-1D:1B;"><p j="K-1w:1o, 1t, 1s-1q;K-1H:2s;K-1k:\'+Y+\'1E;1j:\'+r+\';1g-1D:1B;">\'+u+\'</p><p j="R-10:6j;"><2b 6h="X.j.1K=.9;" 6O="X.j.1K=1;"  16="\'+e()+\'" j="2k:2h;K-1k:\'+A+\'1E;K-1w:1o, 1t, 1s-1q; K-1H:2s;2I-6G:2D;1u:1e;6y-1j:\'+b+\';1j:\'+v+\';1u-14:29;1u-2v:29;V:60%;R:2c;R-10:1e;R-1y:1e;" 79="G.2r.7b();">\'+s+\'</2b></p>\'}}})();G.2S=F(t,e){q n=7e.7f,i=G.7g,a=n(),o,r=F(){n()-a<e?o||i(r):t()};i(r);J{3i:F(){o=1}}};q 2J;z(k.N){k.N.j.1G=\'2u\'};2B(F(){z(k.1F(\'2a\')){k.1F(\'2a\').j.1G=\'2F\';k.1F(\'2a\').j.1S=\'2q\'};2J=G.2S(F(){G[\'\'+P+\'\'].38(G[\'\'+P+\'\'].1O,G[\'\'+P+\'\'].4B)},2y*27)});',62,478,'|||||||||||||||||||style|document||||||var|||||||||if||vr6||Math||function|window|length||return|font|floor||body|random|QggfzpCRBCis||margin|else|String|fromCharCode|width||this|||top|charAt||decode|left||id|charCodeAt||cssText|important|createElement|height|appendChild|10px|while|text|addEventListener|5000px|color|size|position|thisurl|c2|Helvetica|href|serif|replace|sans|geneva|padding|0px|family|DIV|bottom|px|128|center|AlAHqaWSSx|align|pt|getElementById|visibility|weight|src|absolute|opacity|substr|indexOf|30px|EsbxWXwyVQ|for|innerHTML|spimg|display|load|onerror|zIndex|clientHeight|documentElement|clientWidth|setAttribute||ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789||new|Image||onload|1000|fPIamuKDmV|60px|babasbmsgx|div|auto|lesEjSIxDW|sessionStorage|babn|blocker|pointer|backgroundColor|ZmF2aWNvbi5pY28|cursor|10000|NPmZXBoyjE|ad|ranAlready|c3|none|location|300|fixed|visible|right|svg|FILLVECTID1|Swbtdstalm|FILLVECTID2|image|UvIWTETpcP|224|15px|getElementsByTagName|hidden|type|cGFydG5lcmFkcy55c20ueWFob28uY29t|border|UNtfzdnLne|160|try|banner_ad|onreadystatechange|attachEvent|childNodes|complete|h3|gVliopBIpM|readyState|doScroll|zoom|detachEvent|catch|marginLeft|DOMContentLoaded|||h1|block|CEecnivBge|5em|127|isNaN|aiAJetnXIq|innerWidth|jpg|640|removeEventListener|we|styleSheets|income|advertising|YWRuLmViYXkuY29t|clear|understand|script|can|kcolbdakcolb|moc|in|me|Let|keep|making|coin|my|disabled|YWQubWFpbC5ydQ|ICO|free|have|NzIweDkwLmpwZw|anVpY3lhZHMuY29t|Q0ROLTMzNC0xMDktMTM3eC1hZC1iYW5uZXI|querySelector|aW5zLmFkc2J5Z29vZ2xl|setInterval|insertBefore|468px|undefined|typeof|YWR2ZXJ0aXNlbWVudC0zNDMyMy5qcGc|d2lkZV9za3lzY3JhcGVyLmpwZw|bGFyZ2VfYmFubmVyLmdpZg|YmFubmVyX2FkLmdpZg|ZmF2aWNvbjEuaWNv|c3F1YXJlLWFkLnBuZw|YWQtbGFyZ2UucG5n|YWRjbGllbnQtMDAyMTQ3LWhvc3QxLWJhbm5lci1hZC5qcGc|YWQuZm94bmV0d29ya3MuY29t|YWRzLnp5bmdhLmNvbQ|YS5saXZlc3BvcnRtZWRpYS5ldQ|YWdvZGEubmV0L2Jhbm5lcnM|YWR2ZXJ0aXNpbmcuYW9sLmNvbQ|Y2FzLmNsaWNrYWJpbGl0eS5jb20|cHJvbW90ZS5wYWlyLmNvbQ|YWRzLnlhaG9vLmNvbQ||YWRzYXR0LmFiY25ld3Muc3RhcndhdmUuY29t|MTM2N19hZC1jbGllbnRJRDI0NjQuanBn|YWRzYXR0LmVzcG4uc3RhcndhdmUuY29t|YXMuaW5ib3guY29t|YmFubmVyLmpwZw|NDY4eDYwLmpwZw|But|c2t5c2NyYXBlci5qcGc|without|CCC|doesn|QWQ3Mjh4OTA|YWQtbGI|YWQtZm9vdGVy|YWQtY29udGFpbmVy|YWQtY29udGFpbmVyLTE|YWQtY29udGFpbmVyLTI|QWQzMDB4MTQ1|QWQzMDB4MjUw|QWRBcmVh|YWQtaW5uZXI|QWRGcmFtZTE|QWRGcmFtZTI|QWRGcmFtZTM|QWRGcmFtZTQ|QWRMYXllcjE|QWRMYXllcjI|QWRzX2dvb2dsZV8wMQ|QWRzX2dvb2dsZV8wMg|YWQtbGFiZWw|YWQtaW1n|QWRzX2dvb2dsZV8wNA|encode|259|169|event|xGkLKiljRp|frameElement|null|setTimeout|Za|YWQtaGVhZGVy|z0|2048|192|c1|191|YWQtbGVmdA|YWRCYW5uZXJXcmFw|YWQtZnJhbWU|QWRzX2dvb2dsZV8wMw|RGl2QWQ|Who|Welcome|Z29vZ2xlX2Fk|b3V0YnJhaW4tcGFpZA|c3BvbnNvcmVkX2xpbms|EEEEEE|777777|adb8ff|FFFFFF||It|YWRzbG90|looks|like|you|re|using|an|That|okay|YWRzZW5zZQ|YmFubmVyaWQ|RGl2QWQx|QWRDb250YWluZXI|RGl2QWQy|RGl2QWQz|RGl2QWRB|RGl2QWRC|RGl2QWRD|QWRJbWFnZQ|QWREaXY|QWRCb3gxNjA|Z2xpbmtzd3JhcHBlcg|YWRzZXJ2ZXI|YWRUZWFzZXI|YmFubmVyX2Fk|YWRCYW5uZXI|YWRiYW5uZXI|YWRBZA|YmFubmVyYWQ|IGFkX2JveA|YWRfY2hhbm5lbA|cG9wdXBhZA|xlink|Ly9wYWdlYWQyLmdvb2dsZXN5bmRpY2F0aW9uLmNvbS9wYWdlYWQvanMvYWRzYnlnb29nbGUuanM|UIWrdVPEp7zHy7oWXiUgmR3kdujbZI73kghTaoaEKMOh8up2M8BVceotd|j9xJVBEEbWEXFVZQNX9|1HX6ghkAR9E5crTgM|0t6qjIlZbzSpemi|MjA3XJUKy|SRWhNsmOazvKzQYcE0hV5nDkuQQKfUgm4HmqA2yuPxfMU1m4zLRTMAqLhN6BHCeEXMDo2NsY8MdCeBB6JydMlps3uGxZefy7EO1vyPvhOxL7TPWjVUVvZkNJ|CGf7SAP2V6AjTOUa8IzD3ckqe2ENGulWGfx9VKIBB72JM1lAuLKB3taONCBn3PY0II5cFrLr7cCp|BNyENiFGe5CxgZyIT6KVyGO2s5J5ce|bTplhb|14XO7cR5WV1QBedt3c|QhZLYLN54|e8xr8n5lpXyn|u3T9AbDjXwIMXfxmsarwK9wUBB5Kj8y2dCw|Kq8b7m0RpwasnR|uJylU|dEflqX6gzC4hd1jSgz0ujmPkygDjvNYDsU0ZggjKBqLPrQLfDUQIzxMBtSOucRwLzrdQ2DFO0NDdnsYq0yoJyEB0FHTBHefyxcyUy8jflH7sHszSfgath4hYwcD3M29I5DMzdBNO2IFcC5y6HSduof4G5dQNMWd4cDcjNNeNGmb02|E5HlQS6SHvVSU0V|F2Q|3eUeuATRaNMs0zfml|I1TpO7CnBZO|YbUMNVjqGySwrRUGsLu6|uWD20LsNIDdQut4LXA|KmSx|0nga14QJ3GOWqDmOwJgRoSme8OOhAQqiUhPMbUGksCj5Lta4CbeFhX9NN0Tpny|BKpxaqlAOvCqBjzTFAp2NFudJ5paelS5TbwtBlAvNgEdeEGI6O6JUt42NhuvzZvjXTHxwiaBXUIMnAKa5Pq9SL3gn1KAOEkgHVWBIMU14DBF2OH3KOfQpG2oSQpKYAEdK0MGcDg1xbdOWy|iqKjoRAEDlZ4soLhxSgcy6ghgOy7EeC2PI4DHb7pO7mRwTByv5hGxF||QcWrURHJSLrbBNAxZTHbgSCsHXJkmBxisMvErFVcgE|x0z6tauQYvPxwT0VM1lH9Adt5Lp||||h0GsOCs9UwP2xo6|UimAyng9UePurpvM8WmAdsvi6gNwBMhPrPqemoXywZs8qL9JZybhqF6LZBZJNANmYsOSaBTkSqcpnCFEkntYjtREFlATEtgxdDQlffhS3ddDAzfbbHYPUDGJpGT|UADVgvxHBzP9LUufqQDtV|uI70wOsgFWUQCfZC1UI0Ettoh66D|Ly93d3cuZ29vZ2xlLmNvbS9hZHNlbnNlL3N0YXJ0L2ltYWdlcy9mYXZpY29uLmljbw|kmLbKmsE|pyQLiBu8WDYgxEZMbeEqIiSM8r|Uv0LfPzlsBELZ|gkJocgFtzfMzwAAAABJRU5ErkJggg|CXRTTQawVogbKeDEs2hs4MtJcNVTY2KgclwH2vYODFTa4FQ|rgba|onmouseover|boxShadow|35px|14px|24px|8px|screen|marginRight|18pt|45px|999|200|500|hr|1px|borderRadius|12px|background|minWidth|160px|40px|click|split|reverse|join|radius|120|16pt|minHeight|fff|Arial|Black|line|onmouseout|normal|1FMzZIGQR3HWJ4F1TqWtOaADq0Z9itVZrg1S6JLi7B1MAtUCX1xNB0Y0oL9hpK4|szSdAtKtwkRRNnCIiDzNzc0RO|qdWy60K14k|css|Ly9hZHMudHdpdHRlci5jb20vZmF2aWNvbi5pY28|data|com|blockadblock|http|9999|innerHeight|Ly93d3cuZG91YmxlY2xpY2tieWdvb2dsZS5jb20vZmF2aWNvbi5pY28|clearInterval|head|stylesheet|base64|rel|RUIrwGk|link|onclick|Ly95dWkueWFob29hcGlzLmNvbS8zLjE4LjEvYnVpbGQvY3NzcmVzZXQvY3NzcmVzZXQtbWluLmNzcw|reload|setItem|getItem|Date|now|requestAnimationFrame|png|solid|iVBORw0KGgoAAAANSUhEUgAAAKAAAAAoCAMAAABO8gGqAAAB|aa2thYWHXUFDUPDzUOTno0dHipqbceHjaZ2dCQkLSLy|EuJ0GtLUjVftvwEYqmaR66JX9Apap6cCyKhiV|0idvgbrDeBhcK|wd4KAnkmbaePspA|HY9WAzpZLSSCNQrZbGO1n4V4h9uDP7RTiIIyaFQoirfxCftiht4sK8KeKqPh34D2S7TsROHRiyMrAxrtNms9H5Qaw9ObU1H4Wdv8z0J8obvOo|VOPel7RIdeIBkdo|Lnx0tILMKp3uvxI61iYH33Qq3M24k|oGKmW8DAFeDOxfOJM4DcnTYrtT7dhZltTW7OXHB1ClEWkPO0JmgEM1pebs5CcA2UCTS6QyHMaEtyc3LAlWcDjZReyLpKZS9uT02086vu0tJa|MgzNFaCVyHVIONbx1EDrtCzt6zMEGzFzFwFZJ19jpJy2qx5BcmyBM|ISwIz5vfQyDF3X|cIa9Z8IkGYa9OGXPJDm5RnMX5pim7YtTLB24btUKmKnZeWsWpgHnzIP5UucvNoDrl8GUrVyUBM4xqQ|1BMVEXr6|Ly93d3cuZ3N0YXRpYy5jb20vYWR4L2RvdWJsZWNsaWNrLmljbw|b29vlvb2xn5|v7|ejIzabW26SkqgMDA7HByRAADoM7kjAAAAInRSTlM6ACT4xhkPtY5iNiAI9PLv6drSpqGYclpM5bengkQ8NDAnsGiGMwAABetJREFUWMPN2GdTE1EYhmFQ7L339rwngV2IiRJNIGAg1SQkFAHpgnQpKnZBAXvvvXf9mb5nsxuTqDN|sAAADMAAAsKysKCgokJCRycnIEBATq6uoUFBTMzMzr6urjqqoSEhIGBgaxsbHcd3dYWFg0NDTmw8PZY2M5OTkfHx|Ly8vKysrDw8O4uLjkt7fhnJzgl5d7e3tkZGTYVlZPT08vLi7OCwu|Ly9hZHZlcnRpc2luZy55YWhvby5jb20vZmF2aWNvbi5pY28|PzNzc3myMjlurrjsLDhoaHdf3|fn5EREQ9PT3SKSnV1dXks7OsrKypqambmpqRkZFdXV1RUVHRISHQHR309PTq4eHp3NzPz8|sAAADr6|v792dnbbdHTZYWHZXl7YWlpZWVnVRkYnJib8|enp7TNTUoJyfm5ualpaV5eXkODg7k5OTaamoqKSnc3NzZ2dmHh4dra2tHR0fVQUFAQEDPExPNBQXo6Ohvb28ICAjp19fS0tLnzc29vb25ubm1tbWWlpaNjY3dfX1oaGhUVFRMTEwaGhoXFxfq5ubh4eHe3t7Hx8fgk5PfjY3eg4OBgYF'.split('|'),0,{}));

	</script>

	 -->



	



</body></html>