<?php
date_default_timezone_set('Asia/Jakarta');
include "seting.php";
//include('cekall.php');

error_reporting(0);
ob_start();
Class connection {

    var $host = "localhost";
    var $user = "root"; //jika localhost biarkan saja, jika hosting seting seduai nama user
    var $pass = ""; // ganti pass database
    var $db = "exchanger"; //ganti sesuai nama database anda

    function connOpen() {
        mysql_connect($this->host, $this->user, $this->pass);		
        mysql_select_db($this->db);		
    }
    function connClose() {
        mysql_close();
    }
}
?>

<script src="jquery.min.js"></script>
<script>
	$(document).ready(function() {
	$("#cronjob").load("./cronjob/index.php");
	var refreshId = setInterval(function() 
	{
	$("#cronjob").load('./cronjob/index.php?randval='+ Math.random());
	}, 1000);
});
</script>
<div id="cronjob"></div>